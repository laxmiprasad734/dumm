import requests
from collections import defaultdict
from influxdb_client import InfluxDBClient, Point, WritePrecision, WriteOptions
from influxdb_client.client.write_api import SYNCHRONOUS
from datetime import datetime
import logging

BITBUCKET_URL = "https://bitbucket.cotiviti.com/rest/api/1.0"
REPOSITORY_OWNER = "PCAIP_NEW"
REPOSITORY_SLUG = "influxdb2-client-python"
PAT = "MDExMTc1NjE5NTcyOo2l2HFtj2UEzOnn+OAuuzVXquDD"

INFLUXDB_URL = "http://usabuild00.cotiviti.com:8086"
INFLUXDB_TOKEN = "HwnIsYP7s8AxSWQOoPFQHdeCn-EMKgB5GtkMJj7VIT8myDqYBy3X6rsbVhQ4plf8s4EfU6gtENbXd1UgWspkhA=="
INFLUXDB_ORG = "cotiviti.com"
INFLUXDB_BUCKET = "test2"


def get_all_branches():
    branches_url = f'{BITBUCKET_URL}/projects/{REPOSITORY_OWNER}/repos/{REPOSITORY_SLUG}/branches'
    branches = []
    while branches_url:
        response = requests.get(branches_url, headers={'Authorization': f'Bearer {PAT}'})
        response.raise_for_status()
        data = response.json()
        branches.extend(branch['displayId'] for branch in data['values'])
        branches_url = data.get('next')
    return branches

def get_commit_counts_by_user(branch_name):
    user_commit_counts = defaultdict(int)
    commits_url = f'{BITBUCKET_URL}/projects/{REPOSITORY_OWNER}/repos/{REPOSITORY_SLUG}/commits?until={branch_name}&limit=1000'
    while commits_url:
        response = requests.get(commits_url, headers={'Authorization': f'Bearer {PAT}'})
        response.raise_for_status()
        data = response.json()
        for commit in data['values']:
            author = commit['author']['name']
            user_commit_counts[author] += 1
        commits_url = data.get('next')
    return user_commit_counts

def get_pull_request_counts():
    pr_counts = {"MERGED": 0, "OPEN": 0, "DECLINED": 0}
    pr_url = f'{BITBUCKET_URL}/projects/{REPOSITORY_OWNER}/repos/{REPOSITORY_SLUG}/pull-requests?state=ALL'
    while pr_url:
        response = requests.get(pr_url, headers={'Authorization': f'Bearer {PAT}'})
        response.raise_for_status()
        data = response.json()
        for pr in data['values']:
            state = pr['state']
            if state in pr_counts:
                pr_counts[state] += 1
        pr_url = data.get('next')
    return pr_counts

def write_to_influxdb(total_commits, user_commit_counts, pr_counts):
    client = InfluxDBClient(url=INFLUXDB_URL, token=INFLUXDB_TOKEN, org=INFLUXDB_ORG)
    write_api = client.write_api(write_options=WriteOptions(batch_size=1))

    point = Point("commits").field("total_commits", total_commits)
    write_api.write(bucket=INFLUXDB_BUCKET, org=INFLUXDB_ORG, record=point)

    for user, count in user_commit_counts.items():
        point = Point("user_commits").tag("user", user).field("commit_count", count)
        write_api.write(bucket=INFLUXDB_BUCKET, org=INFLUXDB_ORG, record=point)

    for state, count in pr_counts.items():
        point = Point("pull_requests").tag("state", state).field("count", count)
        write_api.write(bucket=INFLUXDB_BUCKET, org=INFLUXDB_ORG, record=point)

    print("Influx write is done")
    client.close()

def get_total_commits_and_user_commits():
    branches = get_all_branches()
    total_commits = 0
    total_user_commits = defaultdict(int)

    for branch in branches:
        print(f'Counting commits for branch: {branch}')
        user_commit_counts = get_commit_counts_by_user(branch)
        total_commits += sum(user_commit_counts.values())
        for user, count in user_commit_counts.items():
            total_user_commits[user] += count
        print(f'Branch: {branch}, User commits: {user_commit_counts}')

    pr_counts = get_pull_request_counts()

    return total_commits, total_user_commits, pr_counts

if __name__ == "__main__":
    total_commits, total_user_commits, pr_counts = get_total_commits_and_user_commits()
    write_to_influxdb(total_commits, total_user_commits, pr_counts)
    print(f'Total number of commits across all branches: {total_commits}')
    print('Total number of commits by each user:')
    for user, count in total_user_commits.items():
        print(f'{user}: {count}')
    print('Total number of pull requests by state:')
    for state, count in pr_counts.items():
        print(f'{state}: {count}')

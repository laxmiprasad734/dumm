import logging
import requests
import time
import sys
from datetime import datetime, timezone
from influxdb_client import InfluxDBClient, Point, WriteOptions
from influxdb_client.client.exceptions import InfluxDBError

BITBUCKET_API_URL = "https://bitbucket.cotiviti.com/rest/api/1.0"
BITBUCKET_TOKEN = ""
INFLUXDB_URL = "http://usabuild00.cotiviti.com:8086"
INFLUXDB_TOKEN = ""
INFLUXDB_ORG = "cotiviti.com"
INFLUXDB_BUCKET = "engineering-metrics"
MAX_RETRIES = 5
RETRY_BACKOFF = 2  

PROJECT_KEY = "PCAPROJECTSAUTOMATION"

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("engineering-metrics-v3.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class BitbucketClient:
    def __init__(self, base_url, token):
        self.base_url = base_url
        self.headers = {"Authorization": f"Bearer {token}"}

    def make_request(self, endpoint, params=None):
        retries = 0
        while retries < MAX_RETRIES:
            try:
                response = requests.get(f"{self.base_url}{endpoint}", headers=self.headers, params=params)
                response.raise_for_status()
                return response.json()
            except requests.exceptions.RequestException as e:
                retries += 1
                backoff_time = RETRY_BACKOFF ** retries
                logger.warning(f"Request failed: {e}. Retrying in {backoff_time} seconds... (Retry {retries}/{MAX_RETRIES})")
                if retries >= MAX_RETRIES:
                    logger.error("Max retries reached. Exiting.")
                    raise
                time.sleep(backoff_time)

    def fetch_repositories(self, project_key):
        logger.info(f"Fetching repositories for project: {project_key}")
        repos_url = f"/projects/{project_key}/repos"
        repositories = []
        params = {'limit': 100}
        while True:
            data = self.make_request(repos_url, params=params)
            if not isinstance(data, dict) or 'values' not in data:
                logger.error(f"Unexpected response format: {data}")
                return []
            repositories.extend(data['values'])
            logger.info(f"Fetched {len(data['values'])} repositories")
            if data.get('isLastPage'):
                break
            params['start'] = data.get('nextPageStart')
        return repositories

    def fetch_branches(self, project_key, repo_slug):
        branches_url = f"/projects/{project_key}/repos/{repo_slug}/branches"
        branches = []
        params = {'limit': 100}
        while True:
            data = self.make_request(branches_url, params=params)
            if not isinstance(data, dict) or 'values' not in data:
                logger.error(f"Unexpected response format: {data}")
                return []
            branches.extend(data['values'])
            if data.get('isLastPage'):
                break
            params['start'] = data.get('nextPageStart')
        return branches

    def fetch_commits(self, project_key, repo_slug, branch_name):
        commits_url = f"/projects/{project_key}/repos/{repo_slug}/commits"
        commits = []
        params = {'limit': 100, 'until': branch_name}
        while True:
            data = self.make_request(commits_url, params=params)
            if not isinstance(data, dict) or 'values' not in data:
                logger.error(f"Unexpected response format: {data}")
                return []
            commits.extend(data['values'])
            if data.get('isLastPage'):
                break
            params['start'] = data.get('nextPageStart')
        return commits

    def fetch_pull_requests(self, project_key, repo_slug):
        pr_url = f"/projects/{project_key}/repos/{repo_slug}/pull-requests"
        pull_requests = []
        params = {'limit': 100, 'state': 'ALL'}
        while True:
            data = self.make_request(pr_url, params=params)
            if not isinstance(data, dict) or 'values' not in data:
                logger.error(f"Unexpected response format: {data}")
                return []
            pull_requests.extend(data['values'])
            if data.get('isLastPage'):
                break
            params['start'] = data.get('nextPageStart')
        return pull_requests

class InfluxDBClientWrapper:
    def __init__(self, url, token, org, bucket):
        self.client = InfluxDBClient(url=url, token=token, org=org)
        self.bucket = bucket
        self.write_api = self.client.write_api(write_options=WriteOptions(batch_size=5000, flush_interval=10_000))

    def write_points(self, points):
        try:
            logger.info(f"Writing {len(points)} data points to InfluxDB")
            self.write_api.write(bucket=self.bucket, record=points)
            self.write_api.flush()
            logger.info("Data successfully written to InfluxDB.")
        except (InfluxDBError, requests.exceptions.RequestException) as e:
            logger.error(f"Error writing to InfluxDB: {e}")
            sys.exit(1)
        finally:
            self.write_api.__del__()
            self.client.__del__()

class DataProcessor:
    @staticmethod
    def calculate_merge_time(pr):
        if pr["state"].lower() == "merged":
            created_time = datetime.fromtimestamp(pr["createdDate"] / 1000.0, tz=timezone.utc)
            merged_time = datetime.fromtimestamp(pr["updatedDate"] / 1000.0, tz=timezone.utc)
            merge_duration = (merged_time - created_time).total_seconds()
            logger.info(f"PR merged in {merge_duration} seconds: created at {created_time}, merged at {merged_time}")
            return merge_duration, merged_time
        return None, None

    def get_user_name(entity):
        """Determine and return the best user identifier, considering both commits and pull-requests."""
        try:
            if "author" in entity:
                if "user" in entity["author"]:
                    user_info = entity["author"]["user"]
                else:
                    user_info = entity["author"]

                if "name" in user_info:
                    name = user_info["name"]
                    if '.' in name and len(name.split('.')) == 2:
                        return name

                if "slug" in user_info:
                    slug = user_info["slug"]
                    if '.' in slug and len(slug.split('.')) == 2:
                        return slug

                if "emailAddress" in user_info:
                    email = user_info["emailAddress"].split('@')[0].lower()
                    if '.' in email and len(email.split('.')) == 2:
                        return email

                if "displayName" in user_info:
                    display_name = user_info["displayName"].split(', ')
                    if len(display_name) == 2:
                        formatted_name = f"{display_name[1].lower()}.{display_name[0].lower()}"
                        return formatted_name

            return "no-identifier"

        except KeyError as e:
            return "no-identifier"
        except Exception as e:
            return "no-identifier"

    @staticmethod
    def process_commits(commits, project_key, repo_slug, branch_name):
        points = []
        total_commits = len(commits)
        for commit in commits:
            user = DataProcessor.get_user_name(commit)
            commit_time = datetime.fromtimestamp(commit["committerTimestamp"] / 1000.0, tz=timezone.utc)
            point = Point("commit") \
                .tag("project_key", project_key) \
                .tag("user", user) \
                .tag("branch", branch_name) \
                .tag("repo", repo_slug) \
                .field("count", 1) \
                .time(commit_time.isoformat())
            points.append(point)
        return points

    @staticmethod
    def process_pull_requests(pull_requests, project_key, repo_slug):
        points = []
        total_prs = len(pull_requests)
        pr_state_counts = {"merged": 0, "declined": 0, "open": 0}
        user_pr_counts = {}
        approved_pr_count = 0
        pr_time = None 

        for pr in pull_requests:
            state = pr["state"].lower()
            user = DataProcessor.get_user_name(pr)
            pr_time = datetime.fromtimestamp(pr["createdDate"] / 1000.0, tz=timezone.utc)

            merge_duration, merged_time = DataProcessor.calculate_merge_time(pr)
            if merge_duration is not None:
                point = Point("pr_merge_time") \
                    .tag("project_key", project_key) \
                    .tag("user", user) \
                    .tag("repo", repo_slug) \
                    .field("merge_duration_seconds", merge_duration) \
                    .time(merged_time.isoformat())
                points.append(point)

            pr_state_counts[state] += 1
            user_pr_counts[user] = user_pr_counts.get(user, 0) + 1

            if state == "merged" and "reviewers" in pr:
                for reviewer in pr["reviewers"]:
                    if reviewer.get("approved", False):
                        approved_pr_count += 1 
                        break  

            point = Point("pull_request") \
                .tag("project_key", project_key) \
                .tag("user", user) \
                .tag("state", state) \
                .tag("repo", repo_slug) \
                .field("count", 1) \
                .time(pr_time.isoformat())
            points.append(point)

        if pr_time:  
            for state, count in pr_state_counts.items():
                point = Point("pull_request_state") \
                    .tag("project_key", project_key) \
                    .tag("state", state) \
                    .tag("repo", repo_slug) \
                    .field("count", count) \
                    .time(pr_time.isoformat())
                points.append(point)

            for user, count in user_pr_counts.items():
                point = Point("pull_request_user") \
                    .tag("project_key", project_key) \
                    .tag("user", user) \
                    .tag("repo", repo_slug) \
                    .field("count", count) \
                    .time(pr_time.isoformat())
                points.append(point)

            point = Point("pr_approval_rate") \
                .tag("project_key", project_key) \
                .tag("repo", repo_slug) \
                .field("approved_pr_count", approved_pr_count) \
                .time(pr_time.isoformat())
            points.append(point)
        return points

def main():
    all_points = []
    try:
        bitbucket = BitbucketClient(BITBUCKET_API_URL, BITBUCKET_TOKEN)
        influxdb = InfluxDBClientWrapper(INFLUXDB_URL, INFLUXDB_TOKEN, INFLUXDB_ORG, INFLUXDB_BUCKET)

        logger.info("Starting the script")

        repositories = bitbucket.fetch_repositories(PROJECT_KEY)
        total_repos = len(repositories)
        logger.info(f"Found {total_repos} repositories in project {PROJECT_KEY}")

        for repo_index, repo in enumerate(repositories, start=1):
            logger.info(f"Processing repository {repo_index}/{total_repos}: {repo['name']} ({repo['slug']})")

            if isinstance(repo, dict) and 'slug' in repo:
                repo_slug = repo['slug']
            else:
                logger.error(f"Unexpected repo format: {repo}")
                continue

            branches = bitbucket.fetch_branches(PROJECT_KEY, repo_slug)
            total_branches = len(branches)

            for branch in branches:
                branch_name = branch['id']
                commits_data = bitbucket.fetch_commits(PROJECT_KEY, repo_slug, branch_name)
                commit_points = DataProcessor.process_commits(commits_data, PROJECT_KEY, repo_slug, branch_name)
                all_points.extend(commit_points)

            pull_requests = bitbucket.fetch_pull_requests(PROJECT_KEY, repo_slug)
            pr_points = DataProcessor.process_pull_requests(pull_requests, PROJECT_KEY, repo_slug)
            all_points.extend(pr_points)

            logger.info(f"Finished processing repository {repo_index}/{total_repos}: {repo_slug}")
            logger.info(f"Total commits for repository '{repo_slug}': {sum(point._fields['count'] for point in commit_points)}")
            logger.info(f"Total pull requests for repository '{repo_slug}': {len(pull_requests)}")
            logger.info(f"Total approved merged PRs for repository '{repo_slug}': {sum(point._fields['approved_pr_count'] for point in pr_points if 'approved_pr_count' in point._fields)}")
            logger.info(f"Total branches for repository '{repo_slug}': {total_branches}")

    except KeyboardInterrupt:
        logger.warning("Script interrupted by user. Attempting to write collected data to InfluxDB...")
        if all_points:
            try:
                influxdb.write_points(all_points)
            except Exception as e:
                logger.error(f"Failed to write data to InfluxDB after interruption: {e}")
        sys.exit(0)
    except (requests.exceptions.RequestException, InfluxDBError) as e:
        logger.error(f"Encountered an error: {e}. Attempting to write collected data to InfluxDB...")
        if all_points:
            try:
                logger.debug(f"Writing the following points to InfluxDB: {all_points}")
                influxdb.write_points(all_points)
            except Exception as ex:
                logger.error(f"Failed to write data to InfluxDB after error: {ex}")
        sys.exit(1)

    if all_points:
        influxdb.write_points(all_points)

    logger.info("Script finished successfully")

if __name__ == "__main__":
    main()

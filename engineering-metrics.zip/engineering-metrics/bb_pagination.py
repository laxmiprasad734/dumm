import subprocess, json, os
import keyring as kr
from datetime import datetime

start_date = input("Enter start_date(Ex: 01 A(a)pril 2024):")
start_date = datetime.strptime(start_date, '%d %B %Y')

end_date = input("Enter end_date(Ex: 20 A(a)pril 2024): ")
end_date = datetime.strptime(end_date, '%d %B %Y')

now = datetime.now().strftime("%Y%m%d%H%M")

getcwd = os.getcwd()
if not os.path.exists(os.getcwd() + '/Output'):
    os.makedirs(os.getcwd() + '/Output')

start=0
project_keys = []
project_endpoint='https://bitbucket.cotiviti.com/rest/api/1.0/projects?start={start}'

while True:
    projects_curl = f'curl -u "svcpbbtjenkins:t#g&zA8e" "{project_endpoint.format(start=start)}"'
    projects_result = subprocess.run(projects_curl, shell=True, check=True, capture_output=True, text=True)
    project_json = json.loads(projects_result.stdout)

    project_keys.extend(project['key'] for project in project_json['values'])

    if project_json['isLastPage']:
        break
    start += 25

print("\n", project_keys, "\n")
project_key = input("Enter a project key from above list:")

def get_commits_data():
    repo_enpoint = 'https://bitbucket.cotiviti.com/rest/api/1.0/projects/{project_key}/repos?start={start}'

    start=0
    while True:
        repo_curl = f'curl -u "svcpbbtjenkins:t#g&zA8e" {repo_enpoint.format(project_key=project_key, start=start)}"'
        repo_result = subprocess.run(repo_curl, shell=True, check=True, capture_output=True, text=True)
        repo_json = json.loads(repo_result.stdout)

        slugs = []
        #slugs.append([project['slug'] for project in repo_json['values']])
        for r in repo_json['values']:
            repo = r['slug']
            slugs.append(repo)

        if repo_json['isLastPage']:
            break
        start += 25 

    for each_slug in slugs:
        commits_endpoint = 'https://bitbucket.cotiviti.com/rest/api/1.0/projects/{project_key}/repos/{each_slug}/commits?start={start}'

        start=0
        commits = []
        while True:
            commits_curl_command = f'curl -u "svcpbbtjenkins:t#g&zA8e" {commits_endpoint.format(project_key=project_key, each_slug=each_slug, start=start)}"'
            commits_result = subprocess.run(commits_curl_command, shell=True, check=True, capture_output=True, text=True)
            commits_json = json.loads(commits_result.stdout)

            commits.extend(commits_json['values'])

            if commits_json['isLastPage']:
                break
            start += 25   

        for each_commit in commits:
            commitBy = each_commit['authorTimestamp']/1000
            each_commit['authorTimestamp'] = datetime.fromtimestamp(commitBy).strftime('%d %B %Y')

            commitAt = each_commit['committerTimestamp']/1000
            each_commit['committerTimestamp'] = datetime.fromtimestamp(commitAt).strftime('%d %B %Y')

            #filtering for start and end dates and sorting them in ascending order
        sorted_commits = sorted(commits, key=lambda x:datetime.strptime(x['committerTimestamp'], "%d %B %Y"))
        commits = [commit for commit in sorted_commits if start_date <= datetime.strptime(commit['committerTimestamp'], '%d %B %Y') <= end_date]                

        if commits:
            commits_file = str(getcwd) + "\\Output\\" +f"{project_key}_commits_{now}.json"
            with open(commits_file, "w") as json_file:
                json.dump(commits, json_file, indent=4)
            print(f"Output written to {commits_file}")

def get_prs():
    repo_enpoint = 'https://bitbucket.cotiviti.com/rest/api/1.0/projects/{project_key}/repos?start={start}'
    pr_repos = []

    start=0
    while True:
        repo_curl = f'curl -u "svcpbbtjenkins:t#g&zA8e" {repo_enpoint.format(project_key=project_key, start=start)}"'
        repo_result = subprocess.run(repo_curl, shell=True, check=True, capture_output=True, text=True)
        repo_json = json.loads(repo_result.stdout)

        for r in repo_json['values']:
            repo = r['slug']
            pr_repos.append(repo)

        if repo_json['isLastPage']:
            break
        start += 25  # Move to the next page

    for each_repo in pr_repos:
        ##OPEN PRs DATA
        open_pullReq_endpoint = 'https://bitbucket.cotiviti.com/rest/api/1.0/projects/{project_key}/repos/{each_repo}/pull-requests?state=OPEN'
        start = 0
        open_prs = []
        while True:
            open_pullReq_curl_command = f'curl -u "svcpbbtjenkins:t#g&zA8e" {open_pullReq_endpoint.format(project_key=project_key, each_repo=each_repo, start=start)}"'
            open_pullReq_result = subprocess.run(open_pullReq_curl_command, shell=True, check=True, capture_output=True, text=True)
            open_pullReq_json = json.loads(open_pullReq_result.stdout)

            open_prs.extend(open_pullReq_json['values'])

            if open_pullReq_json['isLastPage']:
                break
            start += 25

        merged_pullReq_endpoint = 'https://bitbucket.cotiviti.com/rest/api/1.0/projects/{project_key}/repos/{each_repo}/pull-requests?state=MERGED'
        start = 0
        merged_prs = []
        while True:
            mergedPR_curl_command = f'curl -u "svcpbbtjenkins:t#g&zA8e" {merged_pullReq_endpoint.format(project_key=project_key, each_repo=each_repo, start=start)}"'
            merged_pullReq_result = subprocess.run(mergedPR_curl_command, shell=True, check=True, capture_output=True, text=True)
            merged_pullReq_json = json.loads(merged_pullReq_result.stdout)

            merged_prs.extend(merged_pullReq_json['values'])

            if merged_pullReq_json['isLastPage']:
                break
            start += 25

        for opr in open_prs:
            pr_epoch = (opr['createdDate'])/1000
            opr['createdDate'] = datetime.fromtimestamp(pr_epoch).strftime("%d %B %Y")

        sorted_O_dates = sorted(open_prs, key=lambda x:datetime.strptime(x['createdDate'], "%d %B %Y"))
        PR_O_count = [opr for opr in sorted_O_dates if start_date <= datetime.strptime(opr['createdDate'], '%d %B %Y') <= end_date]

        if PR_O_count:
            print("in open prs")
            oprs_file = str(getcwd) + "\\Output\\" +f"{project_key}_openprs_{now}.json"
            with open(oprs_file, "w") as json_file:
                json.dump(PR_O_count, json_file, indent=4)

        ##MERGED PRs DATA       
        for mpr in merged_prs:
            create_epoch = (mpr['createdDate'])/1000
            mpr['createdDate'] = datetime.fromtimestamp(create_epoch).strftime("%d %B %Y")

            update_epoch = (mpr['updatedDate'])/1000
            mpr['updatedDate'] = datetime.fromtimestamp(update_epoch).strftime("%d %B %Y")

            closed_epoch = (mpr['closedDate'])/1000
            mpr['closedDate'] = datetime.fromtimestamp(closed_epoch).strftime("%d %B %Y")

        sorted_M_dates = sorted(merged_prs, key=lambda x:datetime.strptime(x['closedDate'], "%d %B %Y"))
        PR_M_count = [mpr for mpr in sorted_M_dates if start_date <= datetime.strptime(mpr['closedDate'], '%d %B %Y') <= end_date]

        if PR_M_count:
            print('in merged prs')
            mprs_file = str(getcwd) + "\\Output\\" +f"{project_key}_mergedprs_{now}.json"
            with open(mprs_file, "w") as json_file:
                json.dump(PR_M_count, json_file, indent=4)

if __name__ == "__main__":
    get_commits_data()
    get_prs()
./dx_ctl_js_container -d local -configfile ../bin/dxtools.conf -container_name cont1 -action restore -timestamp "2018-01-23 17:02:00"

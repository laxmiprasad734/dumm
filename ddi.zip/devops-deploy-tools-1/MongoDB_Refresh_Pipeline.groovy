import groovy.json.JsonSlurperClassic
import java.text.SimpleDateFormat
node('master'){
  def AuthenticationPassword = "passM17&3G@"
  env.PASSWORD = input message: 'Please enter the password',
                             parameters: [string( description: 'Password to authenticate the pipeline', name: 'Password')]
  def PMPRD1_SNAPSHOT = env.PMPRD1_SNAPSHOT.tokenize(".")[0] + "Z"
  def pattern = "yyyy-MM-dd'T'HH:mm:ssX"
  def DateMap = [:]
  def DateList = []
  def mongoSnapshotsJson, parsedJson, pmprd1_date, Date_Result_ET, clusterStatus, restorationStatus, restoreJobID, NonProd_GroupId, Temp_Cluster_Name
  String Prod_GroupId = "5ecd198c8985297ab6d5a31e"
  def Src_Clustername = env.Src_Clustername //"PROD" // should come from params
  def Dest_Clustername = env.Dest_Clustername // should come from params
  def EmailRecipients = "divya.ballamudi@cotiviti.com,bhanu.makineni@cotiviti.com,satyanarayana.ettamsetty@cotiviti.com"

 
  if ((Src_Clustername == "TEMP") || (Dest_Clustername == "TEMP")){
	NonProd_GroupId = "5e30802b014b76f9c25fbff4"
	Temp_Cluster_Name = "TEMP"
  } else if ((Src_Clustername == "UPPER-TEMP") || (Dest_Clustername == "UPPER-TEMP")){
	NonProd_GroupId = "6356dd858f6f2053f49f612c"
	Temp_Cluster_Name = "UPPER-TEMP"
  } else {
	println "Environment not found"
  }


	try {

		// Get Snapshots of Mongo Prod Cluster
		if (Src_Clustername == "PROD" && env.PASSWORD == AuthenticationPassword ){
			stage("Get Prod MongoDB Snapshots"){
				mongoSnapshotsJson = getMongoSnapshots(Prod_GroupId, Src_Clustername)
			}
			parsedJson = jsonParser(mongoSnapshotsJson)
			parsedJson.results.each {
				def createdAt = it.createdAt.toString()
				//createdAt = Date.parse("yyyy-MM-dd'T'HH:mm:ssX", createdAt)
				createdAt = new SimpleDateFormat(pattern).parse(createdAt)
				DateList.push(createdAt)
				DateMap[createdAt] = it.id
			}

			println "==================== Date List ========================="
			println DateList
			println "================================================================"

			println "==================== Date Map ========================="
			println DateMap
			println "================================================================"
			//pmprd1_date = Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",PMPRD1_SNAPSHOT)
			pmprd1_date = new SimpleDateFormat(pattern).parse(PMPRD1_SNAPSHOT)
			println "==================== PMPRD1 Date ========================="
			println pmprd1_date
			println "================================================================"

			stage("Get Nearest MongoDB Snapshot to pmpr1 snapshot date"){
				Date_Result = getNearestDate(DateList, pmprd1_date)
				println "Date Result after finding nearest date:" + Date_Result
				tz = TimeZone.getTimeZone("America/New_York")
				Date_Result_ET = Date_Result.format("yyyy-MM-dd h:mm a", tz)
				println Date_Result_ET
				println "Snapshotid: "+DateMap[Date_Result]
			}
			//Create Temp Cluster (if doesn't exist)
			stage("Create TEMP cluster if not exists"){
				if (Dest_Clustername == "TEMP" || Dest_Clustername == "UPPER-TEMP" ){
					clusterStatus = sh returnStdout: true, script:"""
					curl --user "hueulpsq:48165828-aa27-4401-8a86-9d2d5a22454f"  --digest --header "Accept: application/json" --header "Content-Type: application/json" -X GET "https://cloud.mongodb.com/api/atlas/v1.0/groups/${NonProd_GroupId}/clusters/${Temp_Cluster_Name}?pretty=true"
					"""
					if(clusterStatus.contains('CLUSTER_NOT_FOUND')){
						createCluster(Temp_Cluster_Name, NonProd_GroupId)
					}
				}
			}
			//Restore Prod Snapshot to Temp cluster
			stage('Restore Prod Snapshot to TEMP cluster'){
				SnapshotID = DateMap[Date_Result]
				restoreJobID = restoreMongoSnapshot(Prod_GroupId, NonProd_GroupId, Src_Clustername, Dest_Clustername, SnapshotID)
				while(!(getRestoreStatus(restoreJobID,Prod_GroupId,Src_Clustername))){
					println "Restore is still in progress... Please wait"
					sh 'sleep 600'
				}
			}
		}
		else if ((Src_Clustername == "TEMP" && env.PASSWORD == AuthenticationPassword) || (Src_Clustername == "UPPER-TEMP" && env.PASSWORD == AuthenticationPassword) ){
			// Create snapshot in TEMP cluster
			stage('Create snapshot in TEMP cluster'){
				SnapshotID = createAndReturnSnapshot(Src_Clustername, NonProd_GroupId)
				while((getSnapshotStatus(Src_Clustername, NonProd_GroupId, SnapshotID)) == "inProgress" || (getSnapshotStatus(Src_Clustername, NonProd_GroupId, SnapshotID)) == "queued"){
					println "Snapshot creation is still in progress... Please wait"
					sh 'sleep 30'
				}
			}
			stage("Restore TEMP snapshot to $Dest_Clustername"){
				restoreJobID = restoreMongoSnapshot(NonProd_GroupId, NonProd_GroupId, Src_Clustername, Dest_Clustername, SnapshotID)
				while(!(getRestoreStatus(restoreJobID,NonProd_GroupId,Src_Clustername))){
					println "Restore is still in progress... Please wait"
					sh 'sleep 60'
				}
			}
		} else {
            stage('Invalid Authentication'){
                error "Invalid authentication password is provided!!!"
            }
        }

	} catch(Exception e){
        println 'Exception occurred: ' + e.toString()
        currentBuild.result="FAILURE"
  }
	finally {
		currentBuild.displayName = "${Src_Clustername} --> ${Dest_Clustername}"
		sendEmailNotification(EmailRecipients,Src_Clustername,Dest_Clustername)
	}
}

@NonCPS
def jsonParser(String mongoJsonData){
    def jsonSlurper = new JsonSlurperClassic()
    def data = jsonSlurper.parseText(mongoJsonData)
    return data
}

def createCluster(String Temp_Cluster_Name, String NonProd_GroupId){
    def createClusterStatus = sh returnStdout: true, script: """
	curl --user "cpxmvnvr:63266923-0481-4b6a-aa8f-dc94370248a0" --digest \
		 --header "Content-Type: application/json" \
		 --include \
		 --request POST "https://cloud.mongodb.com/api/atlas/v1.0/groups/${NonProd_GroupId}/clusters?pretty=true" \
		 --data '
		   {
			 "name": "$Temp_Cluster_Name",
			 "diskSizeGB": 750,
			 "numShards": 1,
			 "mongoDBMajorVersion": "7.0",
			 "providerSettings": {
			   "providerName": "AWS",
			   "instanceSizeName": "M60",
			   "regionName": "US_EAST_1"
			 },
			 "clusterType" : "REPLICASET",
			 "replicationFactor": 3,
			 "pitEnabled" : true,
			 "replicationSpecs": [{
			   "numShards": 1,
			   "regionsConfig": {
				 "US_EAST_1": {
				   "analyticsNodes": 0,
				   "electableNodes": 3,
				   "priority": 7,
				   "readOnlyNodes": 0
				 }
			   },
			   "zoneName": "Zone 1"
			 }],
			 "backupEnabled": false,
			 "providerBackupEnabled" : true,
             "providerSettings" : {
               "providerName" : "AWS",
               "autoScaling" : {
                 "compute" : {
                   "maxInstanceSize" : "M80",
                   "minInstanceSize" : "M60"
                 }
               },
               "diskIOPS": 6000,
               "encryptEBSVolume": true,
               "instanceSizeName": "M60",
               "regionName": "US_EAST_1",
               "volumeType": "PROVISIONED"
             },
			 "autoScaling" : {
               "autoIndexingEnabled" : false,
               "compute" : {
                 "enabled" : true,
                 "scaleDownEnabled" : true
               },
               "diskGBEnabled" : true
             }	 
		   }'
    """
	println "Cluster Creation is in Progress... Please wait...."
	sleep 900
}

def restoreMongoSnapshot(String Src_GroupId, String Dest_GroupId, String Src_Clustername, String Dest_Clustername, String SnapshotID){
    def restoreStatus = sh returnStdout: true, script: """ curl -u "hueulpsq:48165828-aa27-4401-8a86-9d2d5a22454f" --digest \
    --header "Accept: application/json" \
    --header "Content-Type: application/json" \
    --request POST "https://cloud.mongodb.com/api/atlas/v1.0/groups/$Src_GroupId/clusters/$Src_Clustername/backup/restoreJobs?pretty=true" \
    --data '
    {
        "snapshotId" :  "$SnapshotID",
        "deliveryType" : "automated",
        "targetClusterName" : "$Dest_Clustername",
        "targetGroupId" : "$Dest_GroupId"
    }'
    """
	sleep 60
	def restoreJson = jsonParser(restoreStatus)
    println restoreJson
	return restoreJson.id
}

def getMongoSnapshots(String GroupId, String Clustername){
    def mongoSnapshots = sh returnStdout: true, script: """
        curl --user "hueulpsq:48165828-aa27-4401-8a86-9d2d5a22454f" --digest \
		--header "Accept: application/json" \
		--header "Content-Type: application/json" \
		--request GET "https://cloud.mongodb.com/api/atlas/v1.0/groups/${GroupId}/clusters/${Clustername}/backup/snapshots?pretty=true"
    """
    return mongoSnapshots
}

def getRestoreStatus(String restoreJobID, String GroupId, String Clustername){
	def restoreJobStatus = sh returnStdout: true, script:"""
    curl --user hueulpsq:48165828-aa27-4401-8a86-9d2d5a22454f --digest \
    --header "Accept: application/json" \
    --header "Content-Type: application/json" \
    --request GET "https://cloud.mongodb.com/api/atlas/v1.0/groups/${GroupId}/clusters/${Clustername}/backup/restoreJobs/${restoreJobID}?pretty=true"
    """
    def restoreJobStatusJson = jsonParser(restoreJobStatus)
    println restoreJobStatusJson
    println "Restore finish time is : " + restoreJobStatusJson.finishedAt
    if(restoreJobStatusJson.containsKey("finishedAt")) {
        return true
    } else {
        return false
    }
}
public static Date getNearestDate(List<Date> dates, Date PMPRD1_SNAPSHOT) {
  long minDiff = -1, currentTime = PMPRD1_SNAPSHOT.getTime();
  Date minDate = null;
  for (Date date : dates) {
    long diff = Math.abs(currentTime - date.getTime());
    if ((minDiff == -1) || (diff < minDiff)) {
      minDiff = diff;
      minDate = date;
    }
  }
  return minDate;
}
def getSnapshotStatus(String Clustername, String GroupId, String SnapshotID){
	def createSnapshotStatus = sh returnStdout: true, script:"""
    curl --user hueulpsq:48165828-aa27-4401-8a86-9d2d5a22454f --digest \
    --header "Accept: application/json" \
    --header "Content-Type: application/json" \
    --request GET "https://cloud.mongodb.com/api/atlas/v1.0/groups/${GroupId}/clusters/${Clustername}/backup/snapshots/${SnapshotID}?pretty=true"
    """
    def snapshotJson = jsonParser(createSnapshotStatus)
    println "Snapshot creation status is :" + snapshotJson.status
    return snapshotJson.status
}
def createAndReturnSnapshot(String Clustername, String GroupId){
  def createSnapshotStatus = sh returnStdout: true, script:"""
      curl --user hueulpsq:48165828-aa27-4401-8a86-9d2d5a22454f --digest \
      --header "Accept: application/json" \
      --header "Content-Type: application/json" \
      --request POST https://cloud.mongodb.com/api/atlas/v1.0/groups/${GroupId}/clusters/${Clustername}/backup/snapshots?pretty=true \
      --data '
      {
        "description": "On Demand Snapshot by Jenkins",
        "retentionInDays": 5
      }'
      """
	sleep 60
	def snapshotJson = jsonParser(createSnapshotStatus)
	println "Snapshot ID is :" + snapshotJson.id
	return snapshotJson.id
}
def sendEmailNotification(String emailRecipients, String sourceCluster, String destinationCluster){
    if (currentBuild.currentResult == 'SUCCESS'){
		BG_Color="#5bda65"
	} else {
		BG_Color="Tomato"
	}
	emailext attachmentsPattern: '*.LOG', mimeType: 'text/html', body: """<!DOCTYPE html>
		<html>
			<head>
				<style>
					table.blueTable {
					table-layout: auto;
					border: 1px solid #1C6EA4;
					text-align: left;
					border-collapse: collapse;
					}
					table.blueTable td {
					font-size: 18px;
					white-space:nowrap;
					padding:10px;
					border: 1px solid #AAAAAA;
					}
					table.blueTable tr:nth-child(even) {
					/*background: #D0E4F5; */
					}
					table.blueTable thead tr {
					background-color: $BG_Color;
					text-align: center;
					}
					table.blueTable tbody tr td:last-child{
					background-color:#f3f2f2;
					}
				</style>
			</head>
			<body>
				<table class="blueTable">
					<thead>
						<tr>
							<td colspan='2'><b>BUILD REPORT</b></td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><strong>Build No</strong></td>
							<td>${env.BUILD_NUMBER}</td>
						</tr>
						<tr>
							<td><strong>Build URL</strong></td>
							<td>${env.BUILD_URL}</td>
						</tr>
						<tr>
							<td><strong>Source Cluster</strong></td>
							<td>${sourceCluster}</td>
						</tr>
						<tr>
							<td><strong>Destination Cluster</strong></td>
							<td>${destinationCluster}</td>
						</tr>
					</tbody>
				</table>
			</body>
		</html>
		""", subject: "MongoDB Refresh status from $sourceCluster to $destinationCluster is ${currentBuild.currentResult}", to: "PCA-MCurieTeam@cotiviti.com,$emailRecipients"
}

@Library('devops-cicd-library@develop') _
@Library('jboss-deploy-tool@qa') A
import com.cotiviti.*;

def Domain_URL
String Operation = env.Action
try {
	// TODO: Need to update for DEV1/DEV2
	if (env.Environment == 'CICD'){
		Domain_URL= Constants.CICD_JBOSS_URL
	} else if (env.Environment == 'SPTE'){
		Domain_URL= Constants.SPTE_JBOSS_URL
	} else if (env.Environment == 'DEMO'){
		Domain_URL= Constants.DEMO_JBOSS_URL
	} else if ((env.Environment == 'QA') || (env.Environment == 'VPMTST1')){
		Domain_URL= Constants.QA_JBOSS_URL
	} else if ((env.Environment == 'UAT') || (env.Environment == 'VPMUAT1')){
		Domain_URL= Constants.UAT_JBOSS_URL
	} else {
		println "ERROR:Unknown Environment"
		throw e
	}
	println "Jboss Domain URL:" + Domain_URL

	stage(" Trigger Jboss ${Operation}"){
		restartJboss url: "$Domain_URL",
				groups: ['cp-group', 'dacq-group', 'rb-group', 'rm-group'],
				action: "${Operation}"
	}
}
catch(Exception e) {
				println 'Exception occurred: ' + e.toString()
				currentBuild.result="FAILURE"
}
finally {
	stage("Send Email Notification"){
		if (currentBuild.currentResult == 'SUCCESS'){
			BG_Color="#5bda65"
		} else {
			BG_Color="Tomato"
		}
		emailext attachmentsPattern: '', mimeType: 'text/html', body: """<!DOCTYPE html>
			<html>
				<head>
					<style>
						table.blueTable {
						table-layout: auto;
						border: 1px solid #1C6EA4;
						text-align: left;
						border-collapse: collapse;
						}
						table.blueTable td {
						font-size: 18px;
						white-space:nowrap;
						padding:10px;
						border: 1px solid #AAAAAA;
						}
						table.blueTable tr:nth-child(even) {
						/*background: #D0E4F5; */
						}
						table.blueTable thead tr {
						background-color: $BG_Color;
						text-align: center;
						}
						table.blueTable tbody tr td:last-child{
						background-color:#f3f2f2;
						}
					</style>
				</head>
				<body>
					<table class="blueTable">
						<thead>
							<tr>
								<td colspan='2'><b>BUILD REPORT</b></td>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><strong>Build URL</strong></td>
								<td>${env.BUILD_URL}</td>
							</tr>
                            <tr>
								<td><strong>Environment</strong></td>
								<td>${env.Environment}</td>
							</tr>
							<tr>
								<td><strong>Operation</strong></td>
								<td>${env.Action}</td>
							</tr>
							<tr>
								<td><strong>Triggered by</strong></td>
								<td>${env.EmailRecipients}</td>
							</tr>
							<tr>
								<td><strong>TriggeredThru</strong></td>
								<td>${env.TriggeredThru}</td>
							</tr>
						</tbody>
					</table>
				 </body>
			</html>
				""", subject: "Jboss - ${Operation} Operation on ${env.Environment} is ${currentBuild.currentResult}", to: "PCA-MCurieTeam@cotiviti.com,${env.EmailRecipients}"
	}
}
@Library('devops-cicd-library@develop') _

def Release_Name = env.RELEASE_NAME
def SprintName = env.SPRINT_NAME
def Project_Name = env.PROJECT_NAME
def PCA_DB_URL="ssh://git@usapbitbucket01.cotiviti.com:7999/pcadatabase/trunk.git"
def DEVOPS_REPO_URL="ssh://git@usapbitbucket01.cotiviti.com:7999/pcaip/devops-deploy-tools.git"
def EmailRecipients="Satish.Kamuju@cotiviti.com"
def DB_Dirs,Roles_Files,Upgrades_Files
node('maven-jdk8'){
    try{
        if (!(Release_Name ==~ /[A-Z]+-[A-Z]+-\d{1}-\d{1,2}-\d{1}/)){
            error "Please check release name: "+ Release_Name
        }
        stage('Checkout SCM') {
            cleanWs()
            parallel ('DBRepo': {
                checkout([$class: 'GitSCM', branches: [[name: 'refs/heads/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'CloneOption', depth: 1, honorRefspec: true, noTags: true, reference: '', shallow: true], [$class: 'RelativeTargetDirectory', relativeTargetDir: 'pcadb']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'BB_SVC_USER', refspec: '+refs/heads/master:refs/remotes/origin/master', url: "$PCA_DB_URL"]]])
            }, 'DevOpsRepo': {
                checkout([$class: 'GitSCM', branches: [[name: 'refs/heads/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'CloneOption', depth: 1, noTags: false, reference: '', shallow: true], [$class: 'RelativeTargetDirectory', relativeTargetDir: 'devopsrepo']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'BB_SVC_USER', url: "$DEVOPS_REPO_URL"]]])
            })
        }
        dir("${WORKSPACE}"){
            println "Check Release directory existance in db/Upgrades on trunk repo."
            if (!fileExists("pcadb/db/Upgrades/${Release_Name}")){
                error "${Release_Name} does not exists in db/Upgrades."
            }
            String jsonData = readFile("pcadb/db/Upgrades/dbProjects.json")
            def parsedJson=parseJsonResponse(jsonData)
            DB_Dirs = parsedJson.DBProjects."${Project_Name}".DB_Folders
            Roles_Files =  parsedJson.DBProjects."${Project_Name}".Roles_Files
            Upgrades_Files = parsedJson.DBProjects."${Project_Name}".Upgrades_Files
            sh 'chmod +x devopsrepo/dbCreateBranch.sh'
            withCredentials([usernamePassword(credentialsId: 'svcpbbtjenkins', passwordVariable: 'PASSWORD', usernameVariable: 'USERNAME')]){
                sh "${WORKSPACE}/devopsrepo/dbCreateBranch.sh ${Release_Name} ${SprintName} ${Project_Name} \"$USERNAME\" \"$PASSWORD\" ${DB_Dirs} ${Roles_Files} ${Upgrades_Files}"
            }
        }
    } catch(Exception e){
        currentBuild.result='FAILURE'
        println "Code cutoff stage failed"
        throw e   
    }
    finally{
        println "Completed."
        stage("Send Email Notification"){
            if (currentBuild.currentResult == 'SUCCESS'){
                BG_Color="#5bda65"
            } else {
                BG_Color="Tomato"
            }
            emailext attachmentsPattern: '', mimeType: 'text/html', body: """<!DOCTYPE html>
                <html>
                    <head>
                        <style>
                            table.blueTable {
                                table-layout: auto;
                                border: 1px solid #1C6EA4;
                                text-align: left;
                                border-collapse: collapse;
                            }
                            table.blueTable td {
                                font-size: 18px;
                                white-space:nowrap;
                                padding:10px;
                                border: 1px solid #AAAAAA;
                            }
                            table.blueTable tr:nth-child(even) {
                                /*background: #D0E4F5; */
                            }
                            table.blueTable thead tr {
                                background-color: $BG_Color;
                                text-align: center;
                            }
                            table.blueTable tbody tr td:last-child{
                                background-color:#f3f2f2;
                            }
                        </style>
                    </head>
                    <body>
                        <table class="blueTable">
                            <thead>
                                <tr>
                                    <td colspan='2'><b>DB tagging BUILD REPORT</b></td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><strong>Build URL</strong></td>
                                    <td>${env.BUILD_URL}</td>
                                </tr>
                                <tr>
                                    <td><strong>RELEASE TAG</strong></td>
                                    <td>${Release_Name}</td>
                                </tr>
                                <tr>
                                    <td><strong>SPRINT NAME</strong></td>
                                    <td>${SprintName}</td>
                                </tr>
                                <tr>
                                    <td><strong>TAGGED PROJECT</strong></td>
                                    <td>${Project_Name}</td>
                                </tr>
                                <tr>
                                    <td><strong>Triggered by</strong></td>
                                    <td>${env.TriggeredBy}</td>
                                </tr>
                                <tr>
                                    <td><strong>TriggeredThru</strong></td>
                                    <td>${env.TriggeredThru}</td>
                                </tr>
                            </tbody>
                        </table>
                    </body>
                </html>
                """, subject: "Tagging new DB repo i.e. ${Release_Name} for ${Project_Name} is ${currentBuild.currentResult}", to: "PCA-MCurieTeam@cotiviti.com,${EmailRecipients}"
        }
    }
}
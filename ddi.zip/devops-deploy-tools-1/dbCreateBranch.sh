#!/bin/bash

tagName="$1"
SprintName="$2"
Project_Name="$3"
DB_Dirs="$6"
Roles_Dir_Files="$7"
Upgrades_Dir_Files="$8"
PCA_DB_URL="ssh://git@usapbitbucket01.cotiviti.com:7999/pcadatabase/trunk.git"
DEVOPS_REPO_URL="ssh://git@usapbitbucket01.cotiviti.com:7999/pcaip/devops-deploy-tools.git"

echo $tagName
echo $SprintName
echo $Project_Name
echo $DB_Dirs
echo $Roles_Dir_Files
echo $Upgrades_Dir_Files

if [[ "$SprintName" == "NO" ]]; then
	echo "Tagging without Sprint name in TAG."
	tagName="$1"
else
	echo "Tagging with Sprint name in TAG."
	tagName="$1-$2"
fi

cloneName=`echo $tagName | tr '[:upper:]' '[:lower:]'`
echo "tag name: $tagName"
echo "Clone Name: $cloneName"

fork_path="https://usapbitbucket01.cotiviti.com/rest/api/1.0/projects/pcadatabase/repos/ICM-DEV-X-XX-X"
trunk_repo="ssh://git@usapbitbucket01.cotiviti.com:7999/pcadatabase/trunk.git"
tag_repo="ssh://git@usapbitbucket01.cotiviti.com:7999/pcadatabase/$cloneName.git"

git ls-remote $tag_repo

if [[ $? -eq 0 ]] ; then
	echo "Destination repo $tagName already exists. Will proceed to push $Project_Name in the same tag."
	git clone $tag_repo
	cd $cloneName
	IFS=","
	echo "Copying required directories under db to destination"
	for dir in $DB_Dirs
	do
		cp -rf ../pcadb/db/$dir db
	done
	echo "Copying required files under db/Roles to db/Roles in destination."
	for RolesFiles in $Roles_Dir_Files
	do
		cp -rf ../pcadb/db/Roles/$RolesFiles db/Roles
	done
	echo "Copying required files under db/Upgrades/$tagName to destination"
	for UpgradeFiles in $Upgrades_Dir_Files
	do
		cp -rf ../pcadb/db/Upgrades/$1/$UpgradeFiles db/Upgrades/$1
	done
	git config --global user.name \"jenkinsuser\"
	git config --global user.email Jenkins_Devops@cotiviti.com
	git add .
	git commit -m \'"Tagging $1 Release for $Project_Name"\' -q
	git push -u origin master -q
	if [[ $? -eq 0 ]] ; then
		echo "Pushed all required files for $Project_Name on to $1."
	else
		echo "Push failed for $Project_Name on to $1."
	fi
else
	echo "Destination repo $tagName does not exists. Will proceed to tag $Project_Name as a new tag."
	echo "Creating a remote repo from existing template repo using bitbucket API."
	
	curl -X POST -sku "$4":"$5" -H "Content-Type: application/json" $fork_path -d "{ \"name\": \"$tagName\", \"project\": { \"key\": \"PCADATABASE\" } }"
	git ls-remote $tag_repo
	if [[ $? -eq 0 ]] ; then
		echo "New repo forked from template."
		git clone $tag_repo
		cd $cloneName
		mkdir -p db/Upgrades/$1
		mkdir db/Roles
		IFS=","
		echo "Copying required directories under db to destination"
		for dir in $DB_Dirs
		do
			cp -rf ../pcadb/db/$dir db
		done
		echo "Copying required files under db/Roles to db/Roles in destination."
		for RolesFiles in $Roles_Dir_Files
		do
			cp -rf ../pcadb/db/Roles/$RolesFiles db/Roles
		done
		echo "Copying required files under db/Upgrades/$tagName to destination"
		for UpgradeFiles in $Upgrades_Dir_Files
		do
			cp -rf ../pcadb/db/Upgrades/$1/$UpgradeFiles db/Upgrades/$1
		done
		git config --global user.name \"jenkinsuser\"
		git config --global user.email Jenkins_Devops@cotiviti.com
		git add .
		git commit -m \'"Tagging $1 Release for $Project_Name"\' -q
		git push -u origin master -q
		if [[ $? -eq 0 ]] ; then
			echo "Pushed all required files for $Project_Name on to New forked repo i.e. $1."
		else
			echo "Push failed for $Project_Name on to repo $1 failed."
		fi
	else
		echo "ERROR creating fork repo" && exit 1
	fi
fi
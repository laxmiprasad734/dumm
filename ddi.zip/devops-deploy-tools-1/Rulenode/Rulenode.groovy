@Library('devops-cicd-library@rulenode') _
import com.cotiviti.*
def nodeName = env.NodeEnv
def servername = Constants.Rulenodeserver
def inifile,json_clone,json_swap,Env
try{
    node('maven-jdk8'){
        stage('rulenode status'){
        (inifile,json_clone,json_swap,Env) = parseJsonResponse.rulenodestatus(env.NodeEnv) 
            println inifile
            println json_clone
            println json_swap
            println Env
        }
    }
    if (env.Action == "clone" && "$json_clone" == "true"){
        node('vmslave'){
            stage('git clone'){
            checkout([$class: 'GitSCM', branches: [[name: "master"]],doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'LocalBranch', localBranch: "**"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: "svcpbbtjenkins", url: "https://gitlab.cotiviti.com/mcartwright/gold-clone-build.git"]]])
            }
            stage('clone vm'){
                withCredentials([usernamePassword(credentialsId: 'svcpbbtjenkins', passwordVariable:'PASSWORD',usernameVariable: 'USERNAME')]){
                    sh ''' perl -v &&
                        cp -r /home/jenkins/workspace/RuleNode-Refresh/* /var/www/cgi-bin/ &&
                        cd /var/www/cgi-bin/ &&
                        ./clone.pl -u 'cotiviti\\'$USERNAME -p $PASSWORD -c ini/'''+inifile+'''.ini
                        sleep 300s
                        '''
                }
            }
            stage('logs'){
                def Landingdir="~/logs/"
                withCredentials([usernamePassword(credentialsId: 'svcpbbtjenkins', passwordVariable:'PASSWORD',usernameVariable: 'USERNAME')]){
                    sh 'apt-get install sshpass -y'
                    sh ''' sshpass -p $PASSWORD  scp  -oStrictHostKeyChecking=no  /var/www/cgi-bin/logs/*.log  $USERNAME@'''+servername+''':'''+Landingdir+''' '''
                    }
            }
        }			
        node('maven-jdk8'){
            stage('test-clone-staged'){
                withCredentials([usernamePassword(credentialsId: 'svcpbbtjenkins', passwordVariable:'PASSWORD',usernameVariable: 'USERNAME')]){
                    sh ''' sshpass -p $PASSWORD  ssh  -oStrictHostKeyChecking=no  $USERNAME@'''+servername+''' "
                        cd /var/www/cgi-bin/ 
                        sudo ./test-clones.pl -c ini/'''+inifile+'''.ini -v staged
                        "
                    '''
                    }
            }
            if(Env == "Prod"){
                stage('CheckLog') {
                    if (manager.logContains('.*MISS-MATCHED.*')) {
                      error("Build failed because of test-clone-staged APP/DATA is miss-matched")
                    }
                }
            }
            stage('update json file'){
                cleanWs()
                checkout([$class: 'GitSCM', branches: [[name: "master"]],doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'LocalBranch', localBranch: "**"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: "svcpbbtjenkins", url:"ssh://git@usapbitbucket01.cotiviti.com:7999/pcaip/devops-deploy-tools.git"]]])
                def response = readJSON file: 'Rulenode/rulenode.json'
                def builder = response
                builder."${nodeName}".clone = "false"
                builder."${nodeName}".swap = "true" 
                writeJSON file: 'Rulenode/rulenode.json', json: builder, pretty: 4
                sh 'cat Rulenode/rulenode.json'
                sh '''
                    git config --global user.name \"jenkinsuser\"
                    git config --global user.email Jenkins_Devops@cotiviti.com
                    git add Rulenode/rulenode.json
                    git commit -m \"clone and swap status changes updated.\"
                    git push origin HEAD
                ''' 
            }
        }
        }else if (env.Action == "clone" && "$json_clone" == "false"){
            error "Clone operation is already completed. plese perform swap operation"
        }else if (env.Action == "swap" && "$json_swap" == "true"){
            node('maven-jdk8'){
                stage('swap'){
                    withCredentials([usernamePassword(credentialsId: 'svcpbbtjenkins', passwordVariable:'PASSWORD',usernameVariable: 'USERNAME')]){
                        sh ''' sshpass -p $PASSWORD  ssh  -oStrictHostKeyChecking=no  $USERNAME@'''+servername+''' "
                            cd /var/www/cgi-bin/ 
                            sudo ./swap-in.pl -c ini/'''+inifile+'''.ini 
                            sleep 300s
                            "
                        '''
                        }
                }
                stage('test-clone-lived'){
                    withCredentials([usernamePassword(credentialsId: 'svcpbbtjenkins', passwordVariable:'PASSWORD',usernameVariable: 'USERNAME')]){
                        sh ''' sshpass -p $PASSWORD  ssh  -oStrictHostKeyChecking=no  $USERNAME@'''+servername+''' "
                            cd /var/www/cgi-bin/ 
                            sudo ./test-clones.pl -c ini/'''+inifile+'''.ini -v live
                            "
                        '''
                        }
                }
                if(Env == "Prod"){
                    stage('CheckLog') {
                        if (manager.logContains('.*MISS-MATCHED.*')) {
                          error("Build failed because of test-clone-lived APP/DATA is miss-matched")
                        }
                    }
                }
                stage('update json file'){
                        cleanWs()
                        checkout([$class: 'GitSCM', branches: [[name: "master"]],doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'LocalBranch', localBranch: "**"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: "svcpbbtjenkins", url:"ssh://git@usapbitbucket01.cotiviti.com:7999/pcaip/devops-deploy-tools.git"]]])
                        def response = readJSON file: 'Rulenode/rulenode.json'
                        def builder = response
                        builder."${nodeName}".clone = "true"
                        builder."${nodeName}".swap = "false" 
                        writeJSON file: 'Rulenode/rulenode.json', json: builder, pretty: 4
                        sh 'cat Rulenode/rulenode.json'
                        sh '''
                            git config --global user.name \"jenkinsuser\"
                            git config --global user.email Jenkins_Devops@cotiviti.com
                            git add Rulenode/rulenode.json
                            git commit -m \"clone and swap status changes updated.\"
                            git push origin HEAD
                        '''
                    
                }
            }
        }else if (env.Action == "swap" && "$json_swap" == "false"){
            error "please perform clone first before swap"
        }
}
catch(Exception e) {
                println 'Exception occurred: ' + e.toString()
                currentBuild.result="FAILURE"
}
finally{
    stage('Send Email Notification'){
        if (currentBuild.currentResult == 'SUCCESS'){
        BG_Color="#5bda65"
        currentBuild.result="SUCCESS" 
        } else {
            BG_Color="Tomato"
            currentBuild.result="FAILURE"
        }
        if ((env.Action == "clone" && "$json_clone" == "true" ) || (env.Action == "swap" && "$json_swap" == "true")){
            emailext attachLog: true, mimeType: 'text/html', body: """<!DOCTYPE html>
                <html>
                    <head>
                        <style>
                            table.blueTable {
                            table-layout: auto;
                            border: 1px solid #1C6EA4;
                            text-align: left;
                            border-collapse: collapse;
                            }
                            table.blueTable td {
                            font-size: 18px;
                            white-space:nowrap;
                            padding:10px;
                            border: 1px solid #AAAAAA;
                            }
                            table.blueTable tr:nth-child(even) {
                            /*background: #D0E4F5; */
                            }
                            table.blueTable thead tr {
                            background-color: $BG_Color;
                            text-align: center;
                            }
                            table.blueTable tbody tr td:last-child{
                            background-color:#f3f2f2;
                            }
                        </style>
                    </head>
                    <body>
                        <table class="blueTable">
                            <thead>
                                <tr>
                                    <td colspan='2'><b>BUILD REPORT</b></td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><strong>Action</strong></td>
                                    <td>${env.Action}</td>
                                </tr>
                                <tr>
                                    <td><strong>NodeEnv</strong></td>
                                    <td>${NodeEnv}</td>
                                </tr>
                                <tr>
                                    <td><strong>Build URL</strong></td>
                                    <td>${env.BUILD_URL}</td>
                                </tr>
                            </tbody>
                        </table>
                    </body>
                </html>
                    """, subject: "Rule Node Refresh ${env.Action} is ${currentBuild.currentResult}", to: "PPM-MCurieTeam@cotiviti.com,$EmailRecipients"
        }else if(env.Action == "clone" && "$json_clone" == "false"){
            emailext  mimeType: 'text/html', body: """<!DOCTYPE html>
                <html>
                    <head>
                        <style>
                            table.blueTable {
                            table-layout: auto;
                            border: 1px solid #1C6EA4;
                            text-align: left;
                            border-collapse: collapse;
                            }
                            table.blueTable td {
                            font-size: 18px;
                            white-space:nowrap;
                            padding:10px;
                            border: 1px solid #AAAAAA;
                            }
                            table.blueTable tr:nth-child(even) {
                            /*background: #D0E4F5; */
                            }
                            table.blueTable thead tr {
                            background-color: $BG_Color;
                            text-align: center;
                            }
                            table.blueTable tbody tr td:last-child{
                            background-color:#f3f2f2;
                            }
                        </style>
                    </head>
                    <body>
                        <table class="blueTable">
                            <thead>
                                <tr>
                                    <td colspan='2'><b>BUILD REPORT</b></td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><strong>Action</strong></td>
                                    <td>${env.Action}</td>
                                </tr>
                                <tr>
                                    <td><strong>NodeEnv</strong></td>
                                    <td>${NodeEnv}</td>
                                </tr>
                                <tr>
                                    <td><strong>ERROR</strong></td>
                                    <td>Clone operation is already completed. plese perform swap operation</td>
                                </tr>
                                <tr>
                                    <td><strong>Build URL</strong></td>
                                    <td>${env.BUILD_URL}</td>
                                </tr>
                            </tbody>
                        </table>
                    </body>
                </html>""", subject: "Rule Node Refresh ${env.Action} is ${currentBuild.currentResult}", to: "PPM-MCurieTeam@cotiviti.com,$EmailRecipients"
        }else if (env.Action == "swap" && "$json_swap" == "false"){
            emailext  mimeType: 'text/html', body: """<!DOCTYPE html>
                <html>
                    <head>
                        <style>
                            table.blueTable {
                            table-layout: auto;
                            border: 1px solid #1C6EA4;
                            text-align: left;
                            border-collapse: collapse;
                            }
                            table.blueTable td {
                            font-size: 18px;
                            white-space:nowrap;
                            padding:10px;
                            border: 1px solid #AAAAAA;
                            }
                            table.blueTable tr:nth-child(even) {
                            /*background: #D0E4F5; */
                            }
                            table.blueTable thead tr {
                            background-color: $BG_Color;
                            text-align: center;
                            }
                            table.blueTable tbody tr td:last-child{
                            background-color:#f3f2f2;
                            }
                        </style>
                    </head>
                    <body>
                        <table class="blueTable">
                            <thead>
                                <tr>
                                    <td colspan='2'><b>BUILD REPORT</b></td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><strong>Action</strong></td>
                                    <td>${env.Action}</td>
                                </tr>
                                <tr>
                                    <td><strong>NodeEnv</strong></td>
                                    <td>${NodeEnv}</td>
                                </tr>
                                <tr>
                                    <td><strong>ERROR</strong></td>
                                    <td>Swap operation is already completed.Please perform clone operation</td>
                                </tr>
                                <tr>
                                    <td><strong>Build URL</strong></td>
                                    <td>${env.BUILD_URL}</td>
                                </tr>
                            </tbody>
                        </table>
                    </body>
                </html>""", subject: "Rule Node Refresh ${env.Action} is ${currentBuild.currentResult}", to: "PPM-MCurieTeam@cotiviti.com,$EmailRecipients"
        }
    }
}
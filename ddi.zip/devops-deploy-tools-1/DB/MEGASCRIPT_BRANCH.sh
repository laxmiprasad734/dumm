#!/bin/bash

[[ $# -eq 0 ]] && echo "No arguments supplied" && exit 10

if [[ ! -z "$2" ]]; then
	tag_name="$1-$2"
else
	tag_name="$1"
fi

tag_name=`echo $tag_name | tr '[:upper:]' '[:lower:]'`
echo "tag name: $tag_name"

fork_path="https://usapbitbucket01.cotiviti.com/rest/api/1.0/projects/pcadatabase/repos/ICM-DEV-X-XX-X"
trunk_repo="ssh://git@usapbitbucket01.cotiviti.com:7999/pcadatabase/trunk.git"
tag_repo="ssh://git@usapbitbucket01.cotiviti.com:7999/pcadatabase/$tag_name.git"
branch_comment="Tagging $1 Release"

git ls-remote $tag_repo
[[ $? -eq 0 ]] && echo "ERROR: Destination repo already exists" && exit 20

echo "Tagging $1 using $trunk_repo"

echo "Preparing local directory structure for tagging."
[[ -d "retag" ]] && rm -rf retag
mkdir retag && cd retag

# Clone trunk from remote repository.
echo "Clonning trunk from remote repository as $1."

git clone "$trunk_repo" "$1" --depth=1

cd "$1"; rm -rf .git

# Remove directories not in scope of tagging.
echo "Removing directories not in scope of tagging."

cd db
for i in $(ls | egrep -v '(Admin|AUTH_MASTER|AUTH_MASTER_HIST|BLAPP|BLT|BRAT|CDM|CDM_HIST|CIT|CITGCS|CLIENT_PROFILE|CLIENT_PROFILE_HIST|DBUTILS|ELL|ELL_HIST|ICMS7|ICMS_LOADER|IPDE|IPDE_HIST|IRDM|IRDM_HIST|LCD|LCD_HIST|LGLHLD|MDM|MDM_HIST|MDM_STAGE|MICRO_ETL_APP|PAYERS|PAYERS_HIST|PAYER_RULES|PAYER_RULES_HIST|RELEASE_VALIDATION|Report_Local|REPORT_PM|RMI|Roles|Rules|RULES_HIST|RULE_ENGINE|RULE_UPKEEP|RULE_UPKEEP_HIST|RVA_IA|RELEASE_VALIDATION|Upgrades|WebTool_SO)'); do rm -rf $i; done

cd Upgrades
#for j in /*; if [[ $j != $1 ]]; then rm -rf $j; fi; done
for j in $(find . -maxdepth 1 -type d ! \( -name "$1" \)); do rm -rf $j; done

cd ../Roles
for k in $(find . -maxdepth 1 -type f ! \( -name "ROLES_AUTH_MASTER.SQL" -o -name "ROLES_AUTH_MASTER_HIST.SQL" -o -name "ROLES_BLAPP.SQL"  -o -name "ROLES_BLT.SQL" -o -name "ROLES_CDM.SQL" -o -name "ROLES_CDM_HIST.SQL" -o -name "ROLES_DBUTILS.SQL" -o -name "ROLES_ELL.SQL" -o -name "ROLES_ELL_HIST.SQL" -o -name "ROLES_MDM.SQL" -o -name "ROLES_MDM_HIST.SQL" -o -name "ROLES_PAYER_RULES.SQL" -o -name "ROLES_PAYER_RULES_HIST.SQL" -o -name "ROLES_PAYERS.SQL" -o -name "ROLES_PAYERS_HIST.SQL" -o -name "ROLES_RULE_ENGINE.SQL" -o -name "ROLES_RULE_UPKEEP.SQL" -o -name "ROLES_RULES.SQL" -o -name "ROLES_RULES_HIST.SQL" \)); do rm -f $k; done

cd ../../

# Create a fork from existing template repo using bitbucket API.
echo "Creating a remote repo from existing template repo using bitbucket API."
curl -X POST -sku $2:$3 -H "Content-Type: application/json" $fork_path -d "{ \"name\": \"$1\", \"project\": { \"key\": \"PCADATABASE\" } }"

git ls-remote $tag_repo

[[ $? -ne 0 ]] && echo "ERROR creating fork repo" && exit 1

echo "Creating local repo and mapping to remote repo for $1"
echo "Now the changes will be pushed to remote repository."

git config --global user.name \"jenkinsuser\"
git config --global user.email Jenkins_Devops@cotiviti.com
git init && git add . && git commit -m \'"$branch_comment"\'
git remote add tagorigin $tag_repo && git push -u tagorigin master

[[ $? -ne 0 ]] && echo "ERROR pushing changes to fork" && exit 1

cd ../../
rm -rf retag

WHENEVER SQLERROR EXIT SQL.SQLCODE

SPOOL RF_JOB_DROP.LOG;

SET DEFINE ON;
CONNECT RULE_UPKEEP/RULE_UPKEEP@&&DB_INST;
SET SERVEROUTPUT ON SIZE UNLIMITED;

/*****/
/* DROP THE JOB */
declare

v_status int;

begin
select 1 into v_status
   from dba_schduler_jobs
  where job_name='rf_refresh_derived_data';

if v_status=1 then
EXEC  sys.dbms_scheduler.drop_job(job_name => 'rule_upkeep.rf_refresh_derived_data');
end if;

/*****/

SPOOL OFF;

/*****/

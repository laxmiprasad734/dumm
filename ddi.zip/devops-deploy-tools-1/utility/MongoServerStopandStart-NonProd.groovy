
def envs = [ 'DEV', 'QA2', 'TRAINING']
pipeline {
    agent any

    options {
      buildDiscarder(logRotator(numToKeepStr: '30', artifactNumToKeepStr: '30'))
    }    

    parameters {
        choice(name: 'Environment', choices: ['DEV', 'QA1', 'QA2', 'STAGING', 'TRAINING'], description: 'Select the environemnt name')
        choice(name: 'Action', choices: ['', 'status', 'pause', 'start' ], description: 'Select the action')
        string(name: 'ScheduledAction', defaultValue: '', description: 'Keep it empty')
    } 

    triggers {
        parameterizedCron('''
            30 4 * * 1-5 %ScheduledAction=ScheduleStart
            0 23 * * 1-5 %ScheduledAction=ScheduleStop
            0 5 * * 1-5 %ScheduledAction=ScheduleIncrease
            0 22 * * 1-5 %ScheduledAction=SchedulDecrease
        ''')
    } 
   
    stages {
        stage('Start') {
            when {
                expression { params.Action == 'start' }
            }            
            steps {
               script {
                sh """
                 atlas cluster ${params.Action} ${params.Environment}
                 """
               }
            }
        }
        stage('Pause') {
            when {
                expression { params.Action == 'pause' }
            }
            steps {
                script {
                    sh """
                        atlas cluster ${params.Action} ${params.Environment}
                    """
                }
            }
        }
        stage('Status') {
             when {
                expression { params.Action == 'status' }
            }
            steps {
                script {
                    def status = sh(returnStdout: true, script: "atlas cluster describe ${params.Environment} | jq -r .paused").trim()
                    if ("${status}" == "false") {
                        echo "${params.Environment} is running"
                    } else {
                        echo "${params.Environment} is paused"
                    }
                }
            }
        }
        stage('Schedule Stopped') {
             when {
                // triggeredBy 'ParameterizedTimerTriggerCause'
                expression { params.ScheduledAction == 'ScheduleStop' }
            }
            steps {
                script {
                    envs.each { item ->
                    echo "Env is ${item}"
                        def status = sh(returnStdout: true, script: "atlas cluster describe ${item} | jq -r .paused").trim()
                        if ("${status}" == "true" ) {
                            echo "${item} is already paused"
                        } else {
                            echo "${item} is running.. Stopping the env"
                            sh """
                                atlas cluster pause ${item}
                            """
                            echo "${item} is stopped.."
                        }
                    } 
                }
            //    currentBuild.name = "${params.Environment} -- ${params.Action}"
            //     currentBuild.description = "MY_PROJECT MY_VERSION_NUMBER"                 
            }
        }
        stage('Schedule Start') {
             when {
                // triggeredBy 'ParameterizedTimerTriggerCause'
                expression { params.ScheduledAction == 'ScheduleStart' }
            }
            steps {
                // currentBuild.name = "${params.Environment} -- ${params.Action}"
                // currentBuild.description = "MY_PROJECT MY_VERSION_NUMBER"
                script {
                    envs.each { item ->
                    sh """
                        atlas cluster start ${item}
                        """
                    }    
                }
               
            }
        }
        stage('Schedule Decrease') {
             when {
                // triggeredBy 'ParameterizedTimerTriggerCause'
                expression { params.ScheduledAction == 'SchedulDecrease' }
            }
            steps {
                script {
                    envs.each { item ->
                        if ("${item}" == "DEV" ) { 
                            sh """
                                atlas cluster update ${item} --tier M10
                            """
                        } else  {
                            sh """
                                atlas cluster update ${item} --tier M30
                            """
                        }
                    } 
                }
            //    currentBuild.name = "${params.Environment} -- ${params.Action}"
            //     currentBuild.description = "MY_PROJECT MY_VERSION_NUMBER"                 
            }
        }
        stage('Schedule Increase') {
             when {
                // triggeredBy 'ParameterizedTimerTriggerCause'
                expression { params.ScheduledAction == 'ScheduleIncrease' }
            }
            // DEV', 'QA2', 'STAGING', 'TRAINING'
            steps {
                // currentBuild.name = "${params.Environment} -- ${params.Action}"
                // currentBuild.description = "MY_PROJECT MY_VERSION_NUMBER"
                script {
                    envs.each { item ->
                        if ("${item}" == "DEV" ) { 
                            sh """
                                atlas cluster update ${item} --tier M10
                            """
                        } else  {
                            sh """
                                atlas cluster update ${item} --tier M60
                            """
                        }
                    }
                }    
            }
           
        }
    }
    // post {
    //     always {
    //         currentBuild.displayName = '${params.Environment} -- ${params.Action}'
    //     }
    // }
}

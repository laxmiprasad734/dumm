def hostName(Env) {
    if("dev".equals(Env)) {
        return "dev-pl-0.6oxiw.mongodb.net";
    } else if ("dev-temp".equals(Env)) {
        return "devtemp-pl-0.6oxiw.mongodb.net";
    } else if ("temp".equals(Env)) {
        return "temp1-pl-0.6oxiw.mongodb.net";
    } else if ("prod".equals(Env)) {
        return "prod-pl-0.gql4u.mongodb.net";
    } else if ("qa1".equals(Env)) {
        return "qa1-pl-0.6oxiw.mongodb.net";
    } else if ("qa2".equals(Env)) {
        return "qa2-pl-0.6oxiw.mongodb.net";
    } else if ("uat".equals(Env)) {
        return "uat-pl-0.vyanb.mongodb.net";
    } else if ("stage".equals(Env)) {
        return "staging-pl-0.6oxiw.mongodb.net";
    } else if ("demo".equals(Env)) {
        return "demo-pl-0.vyanb.mongodb.net";
    } else if ("test".equals(Env)) {
        return "test-pl-0.6oxiw.mongodb.net";
    } 
}
def getCredenntialName(Env) {
    if("dev".equals(Env)) {
        return "mongoDevCredentialId";
    } else if ("qa1".equals(Env)) {
        return "mongoProdCredentialId";
    } else if ("prod".equals(Env)) {
        return "mongoProdCredentialId";
    } else if ("temp".equals(Env)) {
        return "mongoTempCredentialId";
    } else if ("dev-temp".equals(Env)) {
        return "mongoTempCredentialId";
    } else if ("qa2".equals(Env)) {
        return "mongoProdCredentialId";
    } else if ("uat".equals(Env)) {
        return "mongoProdCredentialId";
    } else if ("stage".equals(Env)) {
        return "mongoProdCredentialId";
    } else if ("demo".equals(Env)) {
        return "mongoProdCredentialId";
    } else if ("test".equals(Env)) {
        return "mongoProdCredentialId";
    } 
}

// def idClientKeyCollections =  [ "categorizeOppty", "categorizeProfileOppty", "changeOpportunity", "changeOpportunityNoActionRequired","changeOpportunityWorked", "clientPrivileges", "cpw_filter", "decision", "historyLog", "notification", "oppty", "pm_filter", "profileChangeOpportunity", "profileOppty", "profileState", "retiredOppty"]
// def clientKeyCollections = ["cpdAudit", "cpdStreamDetails", "dispositionUpdateStatus", "latestDecision", "oppScore", "profile", "profileChangeDescription", "ruleConfigDetails"]
def idClientKeyCollections =  [ "categorizeOppty", "categorizeProfileOppty", "changeOpportunity", "changeOpportunityNoActionRequired","changeOpportunityWorked", "clientPrivileges", "cpw_filter", "decision", "notification", "oppty", "pm_filter", "profileChangeOpportunity", "profileOppty", "profileState", "retiredOppty"]
def clientKeyCollections = ["cpdAudit", "cpdStreamDetails", "latestDecision", "oppScore", "profile", "profileChangeDescription", "ruleConfigDetails"]

pipeline {
  agent {
    kubernetes {
      yaml '''
        apiVersion: v1
        kind: Pod
        spec:
          containers:
          - name: mongo
            image: mongo:latest
            command:
            - cat
            tty: true
        '''
    }    
   }
  parameters {
    choice(name: 'srcenv', choices: ['temp'], description: 'Select source environment')
    choice(name: 'dstenv', choices: ['dev-temp', 'dev', 'qa1', 'qa2', 'uat', 'stage', 'demo'], description: 'Select the destination environmrnt')
    string(name: 'clientKey', defaultValue: '', description: 'select the Client key')
  }

 options {
      buildDiscarder(logRotator(numToKeepStr: '10', artifactNumToKeepStr: '1'))
    }  

  environment { 
    dstHostName = hostName(params.dstenv)
    dstCredentialId = getCredenntialName(params.dstenv)
    srcHostName = hostName(params.srcenv)
    srcCredentialId = getCredenntialName(params.srcenv)
  } 
  stages {
    stage('MongoDB Backup From Source Env') {
      steps {
        container('mongo') {
    
       cleanWs()
       script {

        sh """
        cat > id_clientKey_query.json << EOL
        {
          "_id.clientKey":
           { "\\\$in":[${params.clientKey}]}
        }
EOL
        """
      

        sh """
        cat > clientKey_query.json << EOL
        {
          "clientKey":
           { "\\\$in":[${params.clientKey}]}
        }
EOL
        """  
        for (item in idClientKeyCollections) {
            withCredentials([usernameColonPassword(credentialsId: "${srcCredentialId}", variable:    'USERPASS')]) {
          
                sh """
    
                    mkdir -p ./mongodumps/id_clientkeys
                    mongodump --uri="mongodb+srv://${USERPASS}@${srcHostName}/cpd"  --collection=${item} --queryFile=id_clientKey_query.json --out=./mongodumps/id_clientkeys
                """
            }
          }
        for (item in clientKeyCollections) {
            withCredentials([usernameColonPassword(credentialsId: "${srcCredentialId}", variable:    'USERPASS')]) {
                sh """
                    mkdir -p ./mongodumps/clientkeys
                    mongodump --uri="mongodb+srv://${USERPASS}@${srcHostName}/cpd" --collection=${item} --queryFile=clientKey_query.json --out=./mongodumps/clientkeys
                """
          }
        }
       sh "tar -czvf backup.tar.gz ./mongodumps"
       archiveArtifacts artifacts: 'backup.tar.gz'
      }
    }
    }
    }
    stage('MongoDB Restore To Nonprod') {
      steps {
         container('mongo') {
         script {
          for (item in idClientKeyCollections) {
       withCredentials([usernameColonPassword(credentialsId: "${env.dstCredentialId}", variable: 'USERPASS')]) {
            sh """
            ls -l ./mongodumps/id_clientkeys/cpd/
            mongorestore --uri "mongodb+srv://${USERPASS}@${dstHostName}/cpd" --db=cpd --collection=${item} ./mongodumps/id_clientkeys/cpd/${item}.bson --noIndexRestore
            """
          }
          }
          for (item in clientKeyCollections) {
       withCredentials([usernameColonPassword(credentialsId: "${env.dstCredentialId}", variable: 'USERPASS')]) {
            sh """
            ls -l ./mongodumps/clientkeys/cpd
            mongorestore --uri "mongodb+srv://${USERPASS}@${dstHostName}/cpd" --db=cpd --collection=${item} ./mongodumps/clientkeys/cpd/${item}.bson --noIndexRestore
            """
          }
       }
         }
      }
      }
    }
  }
  post {
      // Clean after build
      always {
          cleanWs()
      }
  }  
}
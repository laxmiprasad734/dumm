def envs = [ 'UAT']
pipeline {
    agent any

    options {
      buildDiscarder(logRotator(numToKeepStr: '30', artifactNumToKeepStr: '30'))
    }

    parameters {
        choice(name: 'Environment', choices: ['UAT'], description: 'Select the environemnt name')
        choice(name: 'Action', choices: ['', 'status', 'pause', 'start' ], description: 'Select the action')
        string(name: 'ScheduledAction', defaultValue: '', description: 'Keep it empty')
    } 

    triggers {
        parameterizedCron('''
            30 4 * * 1-5 %ScheduledAction=ScheduleStart
            0 23 * * 1-5 %ScheduledAction=ScheduleStop
            0 5 * * 1-5 %ScheduledAction=ScheduleIncrease
            0 22 * * 1-5 %ScheduledAction=SchedulDecrease
        ''')
    } 
   
    stages {
        stage('Start') {
            when {
                expression { params.Action == 'start' }
            }            
            steps {
               script {
                sh """
                 atlas cluster ${params.Action} ${params.Environment} --profile UPPER
                 """
               }
            }
        }
        stage('Pause') {
            when {
                expression { params.Action == 'pause' }
            }
            steps {
                script {
                    sh """
                        atlas cluster ${params.Action} ${params.Environment} --profile UPPER
                    """
                }
            }
        }
        stage('Status') {
             when {
                expression { params.Action == 'status' }
            }
            steps {
                script {
                    def status = sh(returnStdout: true, script: "atlas cluster describe ${params.Environment}  --profile UPPER | jq -r .paused").trim()
                    if ("${status}" == "false") {
                        echo "${params.Environment} is running"
                    } else {
                        echo "${params.Environment} is paused"
                    }
                }
            }
        }
        stage('Schedule Stopped') {
             when {
                // triggeredBy 'ParameterizedTimerTriggerCause'
                expression { params.ScheduledAction == 'ScheduleStop' }
            }
            steps {
                script {
                    envs.each { item ->
                    echo "Env is ${item}"
                        def status = sh(returnStdout: true, script: "atlas cluster describe ${item}  --profile UPPER | jq -r .paused").trim()
                        if ("${status}" == "true" ) {
                            echo "${item} is already paused"
                        } else {
                            echo "${item} is running.. Stopping the env"
                            sh """
                                atlas cluster pause ${item}  --profile UPPER
                            """
                            echo "${item} is stopped.."
                        }
                    } 
                }
            //    currentBuild.name = "${params.Environment} -- ${params.Action}"
            //     currentBuild.description = "MY_PROJECT MY_VERSION_NUMBER"                 
            }
        }
        // stage('Schedule Start') {
        //      when {
        //         // triggeredBy 'ParameterizedTimerTriggerCause'
        //         expression { params.ScheduledAction == 'ScheduleStart' }
        //     }
        //     steps {
        //         // currentBuild.name = "${params.Environment} -- ${params.Action}"
        //         // currentBuild.description = "MY_PROJECT MY_VERSION_NUMBER"
        //         script {
        //             envs.each { item ->
        //                 sh """
        //                     atlas cluster start ${item}  --profile UPPER
        //                 """
        //             }    
        //         }
               
        //     }
        // }
        
        stage('Schedule Decrease') {
             when {
                // triggeredBy 'ParameterizedTimerTriggerCause'
                expression { params.ScheduledAction == 'SchedulDecrease' }
            }
            steps {
                script {
                    envs.each { item ->
                        sh """
                            atlas cluster update ${item} --tier M30  --profile UPPER
                        """
                    } 
                }
            }
        }
        // stage('Schedule Increase') {
        //      when {
        //         // triggeredBy 'ParameterizedTimerTriggerCause'
        //         expression { params.ScheduledAction == 'ScheduleIncrease' }
        //     }
        //     steps {
        //         // currentBuild.name = "${params.Environment} -- ${params.Action}"
        //         // currentBuild.description = "MY_PROJECT MY_VERSION_NUMBER"
        //         script {
        //             envs.each { item ->
        //                 sh """
        //                     atlas cluster update ${item} --tier M40  --profile UPPER
        //                 """
        //             }
        //         }    
        //     }
           
        // }
    }
    // post {
    //     always {
    //         currentBuild.displayName = '${params.Environment} -- ${params.Action}'
    //     }
    // }
}
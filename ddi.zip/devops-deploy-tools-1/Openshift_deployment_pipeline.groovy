@Library('devops-cicd-library@rda-docker') _
import com.cotiviti.*
node('kube'){
    def YAML_FILE = "${APP}.yml"
    def URL
	def Projectname = pwd().tokenize('/')[-3].replace("_","").toLowerCase()
	//Need to update pwd with build_url will do shortly
    def GitScm = Constants.BITBUCKET_BASE_URL+"${Projectname}/${APP}.git"
	def Docker_Image = Constants.IPDE_DOCKER_REGISTRY+"${APP}:${Tag}"
	def build_res,build_duration,epoch_time
    
    try{
        stage('Checkout Source'){
            cleanWs()
            checkout([$class: 'GitSCM', branches: [[name: "master"]],doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'LocalBranch', localBranch: "**"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId:'svcpbbtjenkins' , url: "${GitScm}"]]])
        }
        stage('Update Variables'){
            sh '''
                sed -i -e "s/{{tag}}/$Tag/g" -e "s/{{PortNumber}}/$containerPort/g"  -e "s/{{Env}}/$ENV/g" -e "s/{{namespace}}/$NAMESPACE/g"  -e "s/{{App}}/$APP/g" '''+YAML_FILE+''' 
            '''
        }
        stage('Openshift Deployment'){
            sh '''
                kubectl --context="deployer-ipde" apply -f '''+YAML_FILE+''' 
            '''
        }
        stage('Get Hostname'){
            URL=sh(script:"kubectl get routes $APP-$ENV | awk '{print \$2}'",returnStdout: true).replaceAll('HOST/PORT','').trim()
            println "${URL}"
        }
    }
    catch(Exception e) {
        currentBuild.result="FAILURE"
    }
    finally {
		stage('Push to InfluxDB'){
			build_res=currentBuild.currentResult
			build_duration=currentBuild.duration/1000
			epoch_time = sh returnStdout: true, script: 'date +%s%N'
			sh "curl -XPOST '${Constants.INFLUX_DB_URL}/write?db=deploymentDB'  --data-binary 'ocdeployments,Projectname=$Projectname,app_name=$APP,ENV=$ENV,build_result=$build_res,Namespace=$NAMESPACE,DeployedThru=$DeployedThru Docker_Image=\"$Docker_Image\",containerPort=$containerPort,build_number=$env.BUILD_NUMBER,build_url=\"$env.BUILD_URL\",build_agent_name=\"$env.NODE_NAME\",build_exec_time=$build_duration $epoch_time'"
		}
        stage('Send Email Notification'){
            def BG_Color
            if (currentBuild.currentResult == 'SUCCESS'){
                BG_Color="#5bda65"
                } else {
                BG_Color="Tomato"
            }
            emailext attachmentsPattern: '*.LOG', mimeType: 'text/html', body: """<!DOCTYPE html>
            <html>
            <head>
            	<style>
            		table.blueTable {
            		table-layout: auto;
            		border: 1px solid #1C6EA4;
            		text-align: left;
            		border-collapse: collapse;
            		}
            		table.blueTable td {
            		font-size: 18px;
            		white-space:nowrap;
            		padding:10px;
            		border: 1px solid #AAAAAA;
            		}
            		table.blueTable tr:nth-child(even) {
            		/*background: #D0E4F5; */
            		}
            		table.blueTable thead tr {
            		background-color: $BG_Color;
            		text-align: center;
            		}
            		table.blueTable tbody tr td:last-child{
            		background-color:#f3f2f2;
            		}
            	</style>
            </head>
            <body>
            	<table class="blueTable">
            		<thead>
            			<tr>
            				<td colspan='2'><b>DEPLOYMENT REPORT</b></td>
            			</tr>
            		</thead>
            		<tbody>
            			<tr>
            				<td><strong>Build Number</strong></td>
            				<td>${env.BUILD_NUMBER}</td>
            			</tr>
            			<tr>
            				<td><strong>Build URL</strong></td>
            				<td>${env.BUILD_URL}</td>
            			</tr>
                        <tr>
            				<td><strong>Environment</strong></td>
            				<td>${ENV}</td>
            			</tr>
            			<tr>
            				<td><b>Docker Image</b></td>
            				<td>${App}:${Tag}</td>
            			</tr>
            			<tr>
            				<td><b>Application URL</b></td>
            				<td>https://${URL}</td>
            			</tr>
            			
            	    </tbody>
            	</table>
            </body>
            </html>
            """, subject: "Deployment of ${App} on ${ENV} is ${currentBuild.currentResult}", to: "PCA-MCurieTeam@cotiviti.com,tirupathi.singareddy@cotiviti.com,$EmailRecipients"
            
            }
    }
}
#!/bin/bash
echo "Entered bash script"
DB_INST=$1
BB_REPO=$2
cd /tmp
[[ -f SUB_RULES_12C.fmb ]] && rm -f SUB_RULES_12C.fmb
# Get SUB_RULES_12C.fmb file from bitbucket.
git archive --remote ssh://git@usapbitbucket01.cotiviti.com:7999/pcadatabase/${BB_REPO}.git HEAD:db/RMI SUB_RULES_12C.fmb | tar -x
[[ $? -ne 0 ]] && echo "git failed to retrive SUB_RULES_12C.fmb file" && exit 1

echo "Compiling the fmb file"
chmod +x /home/oracle/rmi-repo/scripts/compile_fmb.sh
# Call compile script
/home/oracle/rmi-repo/scripts/compile_fmb.sh ${DB_INST} /tmp/SUB_RULES_12C.fmb
[[ $? -ne 0 ]] && echo "Compilation failed" && exit 1

#DATE_TIME=$( date +%Y%m%d%H )
#[[ -f /forms/SUB_RULES_12C_${DB_INST}_${DATE_TIME}.fmx ]] && rm /forms/SUB_RULES_12C_${DB_INST}_${DATE_TIME}.fmx
COMPILED_FMX=`ls -rt /tmp/SUB_RULES_12C_${DB_INST}_*.fmx | tail -1`
mv ${COMPILED_FMX}  /forms
[[ $? -ne 0 ]] && echo "Failed to deploy SUB_RULES_12C.fmb file" && exit 1

cd /forms
# Select appropriate form name based on the type of environment
case $DB_INST in
        VPMTST1)
                FORM_NAME="SUB_RULES_12C.fmx"
                ;;
        VPMUAT1)
                FORM_NAME="SUB_PMUAT1.fmx"
                ;;
        VPMCICD)
                FORM_NAME="SUB_PMCICD.fmx"
                ;;
        VPMSPTE)
                FORM_NAME="SUB_PMSPTE.fmx"
                ;;
        VPMDEMO)
                FORM_NAME="SUB_PMDEMO.fmx"
                ;;
        *)
                echo "Invalid Environment"
                ;;
esac

# Remove symlink if any and create symlink with new artifact
[[ -L ${FORM_NAME} ]] && unlink ${FORM_NAME}
ln -s $(basename ${COMPILED_FMX})  ${FORM_NAME}

[[ $? -ne 0 ]] && exit 1

echo "Script execution completed"
exit 0


@Library('devops-cicd-library@ccv-automation') _
import com.cotiviti.*;
    
def ENV
def EmailRecipients="CCV-CAT-VEGA@cotiviti.com,CCV-CAT-TRANSFORMERS@cotiviti.com"

if (env.ENVIRONMENT == "QA"){
    ENV="buildQA"
} else if (env.ENVIRONMENT == "DEV"){
    ENV="buildDEV"
} else if (env.ENVIRONMENT == "UAT"){
    ENV="buildUAT"
} else if (env.ENVIRONMENT == "PRE-PROD"){
    ENV="buildPRE-PROD"
} else if (env.ENVIRONMENT == "PROD"){
    ENV="buildPROD"
}

node('maven-jdk8') {
    def Version
    try {
        stage('Checkout Source'){
            cleanWs()
            checkoutSource('ssh://git@usapbitbucket01.cotiviti.com:7999/ccvcat/clientimplementation.git',env.BRANCH_NAME)
        }
        stage ('Compile Source'){
            pom=readMavenPom file: 'pom.xml'
            BUILD_TIME="${DATE_NOW}"
			Version=pom.version.tokenize("-")
			BRANCH=env.BRANCH_NAME.replace('/','-')
			Version[-1]=BRANCH + "_" +BUILD_TIME+ "_" + env.BUILD_NUMBER
			Version=Version.join("-")
            println "$Version"
            dir("${env.WORKSPACE}"){
                compileSource ('-B org.codehaus.mojo:versions-maven-plugin:set',"-DprocessAllModules -DnewVersion=$Version")
                compileSource ('deploy -U',"-s /var/jenkins_home/.m2/settings-ccv.xml -Denv=$ENV -Dmaven.test.skip=false -Dmaven.test.failure.ignore=true")
            }
        }
    }
    catch(Exception e) {
        currentBuild.result="FAILURE"
    }
    finally {
        stage('Send Email Notification'){
            def BG_Color
            def pomVersion, groupID, artifactID
            dir(workspace){
                pom = readMavenPom file: 'pom.xml'
                pomVersion = pom.version
                groupID = pom.groupId
                artifactID = pom.artifactId
            }
            def Nexus3_URL = Constants.CCV_NEXUS_RELEASE_URL+groupID.replace(".", "/")+"/"+artifactID+"/"+pomVersion

            if (currentBuild.currentResult == 'SUCCESS'){
		        BG_Color="#5bda65"
	        } else {
		        BG_Color="Tomato"
	        }

            emailext attachmentsPattern: '*.LOG', mimeType: 'text/html', body: """<!DOCTYPE html>
                <html>
                    <head>
                        <style>
                            table.blueTable {
                            table-layout: auto;
                            border: 1px solid #1C6EA4;
                            text-align: left;
                            border-collapse: collapse;
                            }
                            table.blueTable td {
                            font-size: 18px;
                            white-space:nowrap;
                            padding:10px;
                            border: 1px solid #AAAAAA;
                            }
                            table.blueTable tr:nth-child(even) {
                            /*background: #D0E4F5; */
                            }
                            table.blueTable thead tr {
                            background-color: $BG_Color;
                            text-align: center;
                            }
                            table.blueTable tbody tr td:last-child{
                            background-color:#f3f2f2;
                            }
                        </style>
                    </head>
                    <body>
                        <table class="blueTable">
                            <thead>
                                <tr>
                                    <td colspan='2'><b>BUILD REPORT</b></td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><strong>Build No</strong></td>
                                    <td>${env.BUILD_NUMBER}</td>
                                </tr>
                                <tr>
                                    <td><strong>BRANCH NAME</strong></td>
                                    <td>${env.BRANCH_NAME}</td>
                                </tr>
                                <tr>
                                    <td><strong>ENVIRONMENT</strong></td>
                                    <td>${env.ENVIRONMENT}</td>
                                </tr>
                                <tr>
                                    <td><strong>Build URL</strong></td>
                                    <td>${env.BUILD_URL}</td>
                                </tr>
                                <tr>
                                    <td><strong>Nexus URL</strong></td>
                                    <td>$Nexus3_URL</td>
                                </tr>
                            </tbody>
                        </table>
                    </body>
                </html>
                """, subject: "CCV Payer Configuration build status on ${env.BRANCH_NAME} branch is ${currentBuild.currentResult}", to: "PCA-MCurieTeam@cotiviti.com,tirupathi.singareddy@cotiviti.com,$EmailRecipients"
        }
        
        if (currentBuild.result == 'SUCCESS'){
            stage('clean workspace'){
                cleanWs()
            }
        }
    }
}

@Library('devops-cicd-library@rda-docker') _
import com.cotiviti.*
node('docker'){
    def URL
    def groupID
    def Projectname = pwd().tokenize('/')[-3].replace("_","").toLowerCase()
    //Need to work on pwd 
    def Nexus_Release = Constants.NEXUS3_URL+"repository/maven-releases"
	def Nexus_Snapshots = Constants.NEXUS3_URL+"service/rest/v1/search/assets?repository=maven-snapshots"
    def Docker_Registry = Constants.IPDE_DOCKER_REGISTRY
    def GitScm = Constants.BITBUCKET_BASE_URL+"${Projectname}/${APP}.git"
    def Docker_Image = Docker_Registry+"${APP}:${VERSION}"
	def build_res,build_duration,epoch_time,Branch_Name
    if(env.BranchName) {
        Branch_Name="${BranchName}"
    }
    else {
        Branch_Name="master"
    }
    println Branch_Name
    try {
        stage('Checkout Source'){
                cleanWs()
                sh 'git config --global http.sslVerify false'
                checkout([$class: 'GitSCM', branches: [[name: "${Branch_Name}"]],doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'LocalBranch', localBranch: "**"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId:'svcpbbtjenkins' , url: "${GitScm}"]]])
        }
        stage('Get jar file'){
            pom = readMavenPom file: "pom.xml"
            groupID = pom.groupId
            if (groupID == null){
                groupID = pom.parent.groupId
            }
            //artifactID = pom.artifactId
            if (env.VERSION.contains('-SNAPSHOT')){
                sh '''
                        apk add jq 
                        url=`curl -G "'''+Nexus_Snapshots+'''&maven.groupId='''+groupID+'''&maven.artifactId='''+APP+'''&maven.baseVersion='''+VERSION+'''&maven.extension=jar" | jq -rc '.items | .[].downloadUrl' | sort | tail -n 1`
                        curl $url --output '''+APP+'''-'''+VERSION+'''.jar 
                  '''
            } else {
                groupID = groupID.replace('.','/')
                 sh ''' 
                  curl -LO '''+Nexus_Release+'''/'''+groupID+'''/${APP}/${VERSION}/${APP}-${VERSION}.jar 
                  '''
            }
        }
    	stage('Update Variables'){
    	    sh "sed -i -e 's/version/${VERSION}/g' ./Dockerfile"
    	}
        stage('Build the image'){
            withCredentials([usernamePassword(credentialsId: 'nexus-user', passwordVariable:'NEXUS_PASSWORD',usernameVariable: 'NEXUS_USERNAME')]){
             sh '''
                    docker login -u $NEXUS_USERNAME -p $NEXUS_PASSWORD '''+ Docker_Registry+''' && docker build -t '''+Docker_Image+'''  . 
              '''
            }
        }
        stage('Push the Image'){
            withCredentials([usernamePassword(credentialsId: 'nexus-user', passwordVariable:'NEXUS_PASSWORD',usernameVariable: 'NEXUS_USERNAME')]){
                sh '''
                        docker login -u $NEXUS_USERNAME -p $NEXUS_PASSWORD '''+ Docker_Registry+''' && docker push '''+Docker_Image+''' 
                    '''
            }
        }
        if (!env.VERSION.contains('-SNAPSHOT')){
            stage('Veracode scan'){
                sh ''' 
                    srcclr scan --image  '''+Docker_Image+''' >> ${WORKSPACE}/detailedreport.txt 
                '''
            }
            stage('Get Report'){
            sh ''' 
                    apk update && apk add libreoffice
                    libreoffice --convert-to "pdf" ${WORKSPACE}/detailedreport.txt
               '''
            }
            stage("Get the report url "){
               URL= sh(script:"grep -w 'Full Report Details' ${WORKSPACE}/detailedreport.txt | awk '{print \$4}'",returnStdout: true)
               println "${URL}"
            }
        }
        stage('Delete Local Image '){
            sh '''
                    docker rmi '''+Docker_Image+''' 
            '''
        }
    }
    catch(Exception e) {
        currentBuild.result="FAILURE"
    }
    finally {
		stage('Push to InfluxDB'){
			build_res=currentBuild.currentResult
			build_duration=currentBuild.duration/1000
			epoch_time = sh returnStdout: true, script: 'date +%s%N'
			sh "curl -XPOST '${Constants.INFLUX_DB_URL}/write?db=ipde_jenkins_build_data'  --data-binary 'Image_Build_data,Projectname=$Projectname,app_name=$APP,build_result=$build_res,BuildThru=$BuildThru Docker_Image=\"$Docker_Image\",build_number=$env.BUILD_NUMBER,build_url=\"$env.BUILD_URL\",build_agent_name=\"$env.NODE_NAME\",build_exec_time=$build_duration $epoch_time'"
		}
        stage('Send Email Notification'){
            if (!env.VERSION.contains('-SNAPSHOT')){
              sendDockerEmailNotification("$EmailRecipients","$APP","${VERSION}","$URL")
            }else{
               sendDockerEmailNotification("$EmailRecipients","$APP","${VERSION}") 
            }
        }
    }
 }
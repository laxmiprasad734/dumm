@Library('devops-cicd-library@develop') _

def node_name
int return_code
try {
    node('master'){
        if (env.Environment == 'VPMCICD'){
            node_name = "LEI-CICD" 
        }
        else if(env.Environment == 'VPMSPTE'){
            node_name = "LEI-SPTE"
        }
        else if(env.Environment == 'VPMDEMO'){
            node_name = "LEI-DEMO"
        }
        else if(env.Environment == 'VPMUAT1'){
            node_name = "LEI-UAT"
        }
        else if(env.Environment == 'VPMTST1'){
            node_name = "LEI-TST"
        }
        else {
            println "Unsupported environment"
            throw e
        }
    }
    node(node_name){
        dir('D:\\Domino'){
            if(env.Operation == 'stop'){
                stage('Stop LEI'){
                    println "Performing $env.Operation on $node_name"
                    return_code=bat returnStatus: true, script: '''
                    nserver.exe -c "tell lei quit"
                    '''
                    println return_code
                    if (return_code != 35110) {
                        throw new Exception("$env.Operation Operation on $node_name. Please check Logs.")
                    }
                    sleep 30
                }
                stage('Clean cache'){
                    println "Do a cache clean"
                    Clean_Cache_Status=bat returnStatus: true, script: '''
                    nserver.exe -c "Tell amgr run IT\\WebServices\\NotesWebServices.nsf 'ClearOldData'"
                    '''
                }
            }
            else if(env.Operation == 'start'){
                stage('Start LEI'){
                    println "Performing $env.Operation on $node_name"
                    return_code=bat returnStatus: true, script: 'nserver.exe -c "load lei"'
                    println return_code
                    if (return_code != 35110) {
                        throw new Exception("$env.Operation Operation on $node_name. Please check Logs.")
                    }
                    sleep 30
                }
            }
        }
    }
}
catch(Exception e) {
    println 'Exception occurred: ' + e.toString()
    currentBuild.result="FAILURE"
}
finally {
    stage("Send Email Notification"){
        if (currentBuild.currentResult == 'SUCCESS'){
        BG_Color="#5bda65"
        } else {
        BG_Color="Tomato"
        }        
        emailext attachmentsPattern: '', mimeType: 'text/html', body: """<!DOCTYPE html>
            <html>
                <head>
                    <style>
                        table.blueTable {
                        table-layout: auto;
                        border: 1px solid #1C6EA4;
                        text-align: left;
                        border-collapse: collapse;
                        }
                        table.blueTable td {
                        font-size: 18px;
                        white-space:nowrap;
                        padding:10px;
                        border: 1px solid #AAAAAA;
                        }
                        table.blueTable tr:nth-child(even) {
                        /*background: #D0E4F5; */
                        }
                        table.blueTable thead tr {
                        background-color: $BG_Color;
                        text-align: center;
                        }
                        table.blueTable tbody tr td:last-child{
                        background-color:#f3f2f2;
                        }
                    </style>
                </head>
                <body>
                    <table class="blueTable">
                        <thead>
                            <tr>
                                <td colspan='2'><b>BUILD REPORT</b></td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><strong>Environment</strong></td>
                                <td>${env.Environment}</td>
                            </tr>
                            <tr>
                                <td><strong>Build URL</strong></td>
                                <td>${env.BUILD_URL}</td>
                            </tr>
                            <tr>
                                <td><strong>Operation</strong></td>
                                <td>${env.Operation}</td>
                            </tr>
                            <tr>
                                <td><strong>Triggered by</strong></td>
                                <td>${env.EmailRecipients}</td>
                            </tr>						
                            <tr>
                                <td><strong>TriggeredThru</strong></td>
                                <td>${env.TriggeredThru}</td>
                            </tr>						
                        </tbody>
                    </table>
                </body>
            </html>
                """, subject: "LotusNotes - ${env.Operation} Operation on ${env.Environment} is ${currentBuild.currentResult}", to: "PCA-MCurieTeam@cotiviti.com,${env.EmailRecipients}"
    }
}

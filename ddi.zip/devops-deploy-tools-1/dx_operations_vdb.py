#!/usr/bin/env python
# Sai Krishna Anantaraju - Aug 2020
# This script snapshots/rewinds a VDB
#Requirements
#pip install docopt
"""This script snapshots/rewinds a VDB
Usage:
  dx_operations_vdb.py (--vdb <name> (--snapshot | --rewind) --engine <name>) (--username <user_name>) (--password <pwd>) [--debug]
  dx_operations_vdb.py --list -u <user_name> -p <pwd> --engine <name>

  dx_operations_vdb.py -h | --help

Examples:
  dx_operations_vdb.py --vdb vpmcicd --snapshot -u username -p password --engine delphix
  dx_operations_vdb.py --vdb vpmcicd --rewind -u username -p password --engine delphix --debug
  dx_operations_vdb.py --list -u username -p password --engine delphix

Options:
  --vdb <name>              Name of the VDB on which task needs to be performed
  --list                    List all databases
  --snapshot                Snapshot the VDB provided
  --rewind                  Rewind the VDB provided to the snapshot state
  -u --username <user_name> Delphix username
  -p --password <pwd>       Delphix password
  --engine <name>           Name of the Delphix engine
  -h --help                 Show this screen
"""
VERSION = 'v0.1'

# TODO: First step is to create a session
import requests, json, re
from os.path import basename
from docopt import docopt

session = requests.session()
session.headers.update({'Content-Type': 'application/json'})

def _post(api, data, raise_errors = True):
	try:
		response = session.post(api, json = data)
		print(response.content)
		response.raise_for_status()
	except:
		if raise_errors:
			raise

def createSession(url):
    _post(url + '/session', {'type': 'APISession', 'version':{'type': 'APIVersion', 'major': 1, 'minor': 9, 'micro': 0 }})

def loginRequest(url):
    _post(url + '/login', {'type': 'LoginRequest', 'username': arguments['--username'], 'password': arguments['--password']})

def list(url): #TODO: to list all databases to which service account has access
	api_call = session.get(url + '/database')
	result = json.loads(api_call.content)
	for db in result['result']:
		print("Database name: {0} | Reference Container: {1}" .format(db['name'], db['reference']))

# Get database list and findout reference container
def getReferenceContainer(url):
    ReferenceContainer=None
    api_call = session.get(url + '/database')
    result = json.loads(api_call.content)
    #print result
    for json_obj in result['result']:
        match = re.search(arguments['--vdb'], json_obj['name'], flags=re.IGNORECASE)
        if (match): # TODO: get this value from input parameter
            ReferenceContainer = json_obj['reference']
            print("Reference Container:{0}".format(ReferenceContainer))
            return ReferenceContainer

def snapshotVDB(url, referenceContainer):
    _post(url + '/database/' + referenceContainer + '/sync', { })

def getTimeFlow(url, referenceContainer):
    print referenceContainer
    #print(type(referenceContainer))
    timeflow=None
    api_call = session.get(url + '/snapshot?database=' +referenceContainer)
    result = json.loads(api_call.content)
    for json_obj in result['result']:
        timeflow = json_obj['latestChangePoint']['timeflow']
        break
    return timeflow

def rewindVDB(url, referenceContainer, timeflow):
    json_data = { "type": "OracleRollbackParameters", "timeflowPointParameters": { "type": "TimeflowPointSemantic", "container": referenceContainer, "timeflow": timeflow, "location": "LATEST_SNAPSHOT" } }
    _post(url + '/database/' + referenceContainer + '/rollback', json_data)

def main(argv):
    url = 'http://'+arguments['--engine']+'/resources/json/delphix'
    print url
    createSession(url)
    loginRequest(url)
    referenceContainer = getReferenceContainer(url)
    #print(type(referenceContainer))
    referenceContainer = referenceContainer.encode('ascii','ignore')
    #print(type(referenceContainer))
    if arguments['--list']:
        list(url)
    if arguments['--snapshot']:        
        snapshotVDB(url, referenceContainer)
    if arguments['--rewind']:
        timeflow=getTimeFlow(url, referenceContainer)
        rewindVDB(url, referenceContainer, timeflow)

if __name__ == "__main__":
    # Grab our arguments from the doc at the top of the script
    arguments = docopt(__doc__, version=basename(__file__) + " " + VERSION)
    main(arguments)

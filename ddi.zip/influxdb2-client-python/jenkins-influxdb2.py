import json, time, sys, re, os, subprocess
from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS
from datetime import datetime

seconds = time.time_ns()
app_name = sys.argv[1]
build_branch_name = sys.argv[2]
build_result = sys.argv[3]
build_agent_name = sys.argv[4]
jenkins_build_number = sys.argv[5]
build_duration = sys.argv[6]
build_url = sys.argv[7]
job_name = sys.argv[8]
token = sys.argv[9]
org = sys.argv[10]
bucket = sys.argv[11]

def injectToInflux(json_body):
   client = InfluxDBClient(url="http://usdcpddocker01.cotiviti.com:8087", token=token)
   write_api = client.write_api(write_options=SYNCHRONOUS)
   write_api.write(bucket, org, json_body, debug=True)
   client.close()

json_body = [
            {
                "measurement": "raw_data",
                "tags": {   
                    "app_name": str(app_name),
                    "build_branch_name" : str(build_branch_name),
                    "job_name" : str(job_name),
                    "build_result" : str(build_result)    
                },
                "time": int(seconds),
                "fields": {
                    "build_agent_name": str(build_agent_name),
                    "jenkins_build_number": int(jenkins_build_number) ,
                    "build_duration": float(build_duration),
                    "build_url" : str(build_url)
                }
            }
        ]

injectToInflux(json_body)
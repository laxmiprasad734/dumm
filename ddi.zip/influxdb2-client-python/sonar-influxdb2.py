from http.client import responses
import json, time, sys, re, os, subprocess
from logging import exception
from tabnanny import verbose
from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.exceptions import InfluxDBError
from influxdb_client.client.write_api import SYNCHRONOUS
import logging

org = "cotiviti"
bucket = "devops"
influxtoken = "6RlS-HF2-l7E_NggxMVtF71p9jAKSwlUf4tX0qE_yGqupi59hSwrwWeWFU-lkdon-PJ4_22LDzRK8KfJYKMpKg=="

app_name = sys.argv[1]
branch_name = sys.argv[2]
bugs = sys.argv[3]
Coverage = sys.argv[4]
Complexity = sys.argv[5]
Code_Smells = sys.argv[6]
Duplicated_Code = sys.argv[7]
Vulnerabilities = sys.argv[8]
QualityGateStatus = sys.argv[9]
TechnicalDebt = sys.argv[10]
seconds = time.time_ns()


json_body = [
            {
                "measurement": "sonarmetrics",
                "tags": {   
                    "app_name": app_name,
                    "branch_name": branch_name
                },
                "time": int(seconds),
                "fields": {
                    "bugs" : bugs,
                    "Coverage" : Coverage,
                    "Complexity" : Complexity,
                    "Code_Smells" : Code_Smells,
                    "Duplicated_Code" : Duplicated_Code,
                    "Vulnerabilities" : Vulnerabilities,
                    "QualityGateStatus" : QualityGateStatus,
                    "TechnicalDebt" : TechnicalDebt
                }
            }
        ]

def injectToInflux(json_body):
    with InfluxDBClient(url="http://usdcpddocker01.cotiviti.com:8087", token=influxtoken, org=org) as client:
        write_api = client.write_api(write_options=SYNCHRONOUS)
        try:
            data_test= write_api.write(bucket, org, json_body)
            data_test.get()
        except InfluxDBError as err:
           logging.error('Write to database failed: %s' % err)
        client.close()

injectToInflux(json_body)

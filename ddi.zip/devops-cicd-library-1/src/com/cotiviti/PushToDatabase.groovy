package com.cotiviti

import com.cotiviti.Constants

void push(String responseCode, String bugsCount, String codeSmellsCount, String duplicatedCode, String vulnerabilitiesCount, String qualityGateStatus){
    def ParsedJson = parseJsonResponse(responseCode)
    def SonarAnalysisDate = ParsedJson.component.analysisDate
    println SonarAnalysisDate
    def SonarAnalysisId = ParsedJson.component.id
    def EpochTime = sh label: '', returnStdout: true, script: "date --date=$SonarAnalysisDate +%s%N"
    def GatingStatus
    if (qualityGateStatus == 'OK'){
        GatingStatus = "Passed"
    } else {
        GatingStatus = "Failed"
    }
    def jobName=sh(returnStdout: true, script: 'echo $JOB_NAME | cut -d \'/\' -f2').trim()
    sh script: "curl -i -s -X POST '${Constants.INFLUX_DB_URL}/write?db=sonar_cotiviti' --data-binary 'sonar_data,job_name=$jobName,user=jenkins id=\"$SonarAnalysisId\",Bugs=$bugsCount,Code_Smells=$codeSmellsCount,Duplicated_Code=$duplicatedCode,Vulnerabilities=$vulnerabilitiesCount,QualityGateStatus=\"$GatingStatus\"  $EpochTime'"
}
package com.cotiviti

class Constants {
	static final SONAR_HOST_URL = 'https://bamboo.ihtech.com/sonarqube'
	static final NEXUS_RELEASE_URL = 'https://usabuild00.cotiviti.com/nexus/service/rest/repository/browse/maven-releases/'
	static final NEXUS_SNAPSHOT_URL = 'https://usabuild00.cotiviti.com/nexus/service/rest/repository/browse/maven-snapshots/'
	static final RCP_NEXUS_RELEASE_URL = 'https://jenkins-build.cotiviti.com/pcarcp/nexus/content/groups/pca-public/'
	static final RCP_NEXUS_SNAPSHOT_URL = 'https://jenkins-build.cotiviti.com/pcarcp/nexus/content/repositories/pca-snapshots/'
	static final INFLUX_DB_URL = 'http://usdcpddocker01:8086'
	static final BITBUCKET_CREDENTIALS_ID = 'svcpbbejenkins_enterprise'

}

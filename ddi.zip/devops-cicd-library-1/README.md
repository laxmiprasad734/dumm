# Jenkins Shared Pipeline Library

This repository holds the Jenkins shared library for PCA Continuous Integration (CI) and Continuous Delivery (CD) process.

## Purpose
It’s always recommended to use libraries for common logic used across all the Jenkins pipelines. Libraries make pipelines look better for developers in terms of understanding and readability. They also help DevOps engineers to abstract underlying code which is of no interest to dev team, ease of maintenance and most importantly, reusability.

## Setting up Global pipeline library in Jenkins
- Go to **Manage Jenkins -> Configure System -> Global pipeline libraries -> Add**
- Give a name to the library and set default version as develop.
- In retrieval method, select Modern SCM and then select Git.
- Provide the URL of this repository and then provide credentials.

## Import library in your Jenkins pipeline
- Add the line at the top of your Jenkinsfile that looks like `@Library(‘<name of the library>’) _`
- Optionally you can give the branch name as well which will look like `@Library(‘<name of the library>@<branch name>’) _`

## Usage
Now that you’re all set to use library, let’s see how to use each library.
Groovy scripts under ‘vars’ are used as calling methods (without .groovy extension) inside Jenkinsfile.
For more information on this, please refer to official Jenkins documentation https://jenkins.io/doc/book/pipeline/shared-libraries/

## Libraries used in PCA CI/CD process
[checkoutSource.groovy](https://usapbitbucket01.cotiviti.com/projects/PCAIP/repos/devops-cicd-library/browse/vars/checkoutSource.groovy)
Used to clone bitbucket source code. This library accepts 2-3 parameters, bitbucket SSH URL and branch name. Optionally you can supply another parameter to clone the bitbucket repo to a specific folder.
**Usage:**

 - checkoutSource(‘ssh://bitbucketurl.git’, 'branch name')
 - checkoutSource(‘ssh://bitbucketurl.git’, 'branch name', ‘Folder
   name’)

[compileSource.groovy](https://usapbitbucket01.cotiviti.com/projects/PCAIP/repos/devops-cicd-library/browse/vars/compileSource.groovy)
Used to do maven compilation of the source code. This library accepts 2 parameters, maven goals and maven parameters.
**Usage:**

 - compileSource(‘clean install’, ‘-Dmaven.test.skip=true’)

[getAndPushSonarMetrics.groovy](https://usapbitbucket01.cotiviti.com/projects/PCAIP/repos/devops-cicd-library/browse/vars/getAndPushSonarMetrics.groovy)
This script is used to collect SonarQube metrics based on the project key and push to database.
**Usage:**

 - getAndPushSonarMetrics(‘Sonar project key’)

[getPipeline.groovy](https://usapbitbucket01.cotiviti.com/projects/PCAIP/repos/devops-cicd-library/browse/vars/getPipeline.groovy)
Used to select Jenkins pipeline based on the branch type. Returns ‘feature-pipeline.groovy’ file if  branch name starts with ‘feature/’. Similarly for release branch, it returns ‘release-pipeline.groovy’ and if PR, it returns ‘pr-pipeline.groovy’
**Usage:**

    / / it will look like this
    def pipeline=getPipeline()
[getPomVersion.groovy](https://usapbitbucket01.cotiviti.com/projects/PCAIP/repos/devops-cicd-library/browse/vars/getPomVersion.groovy)
Used to set custom pom version based on the type of build. For feature branch, git commit's short revision will be appended to the version. Whereas for release pipeline, Jenkins build number will be appended. This library is used for creating release versions only in a few cases where release plugin cannot be used. This library accepts only 1 parameter.
**Usage**
- getPomVersion('workspace')

[parseJsonResponse.groovy](https://usapbitbucket01.cotiviti.com/projects/PCAIP/repos/devops-cicd-library/browse/vars/parseJsonResponse.groovy)
This library will use a simple json parser to parse the response from an API call and return the same so that we can access values as key/value pairs.
**Usage**
- parseJsonResponse('API output string')

[pushToDB.groovy](https://usapbitbucket01.cotiviti.com/projects/PCAIP/repos/devops-cicd-library/browse/vars/pushToDB.groovy)
This library will push all the SonarQube metrics to database. It takes all metrics as parameters including sonar components API response ("sonar_host_baseurl/api/components/show?key=sonarProjectKey")
**Usage**
- pushToDB('response', 'bugsCount', 'codeSmellsCount', 'duplicatedCode', 'vulnerabilitiesCount')

[sendEmailNotification.groovy](https://usapbitbucket01.cotiviti.com/projects/PCAIP/repos/devops-cicd-library/browse/vars/sendEmailNotification.groovy)
As the name says, it's used for sending email notification to the concerned group about the status of your build/deployment. Based on whether an application has SonarQube scanning done or not, this library  supports 2 overloaded methods that take in 2-3 parameters.
**Usage**

 - sendEmailNotification('EmailRecipientslist', 'sonarProjectKey',  'sonarProjectName')
 - sendEmailNotification('EmailRecipientslist', 'ProjectName')

[sonarQubeAnalysis.groovy](https://usapbitbucket01.cotiviti.com/projects/PCAIP/repos/devops-cicd-library/browse/vars/sonarQubeAnalysis.groovy)
This is used to run SonarQube analysis. This is based on the sonar-scanner tool configured in Jenkins. This library takes in multiple parameters required for triggering sonarqube scan.
**Usage**
sonarQubeAnalysis("sonarProjectKey", "sonarProjectName", "sonarProjectVersion", "sonarProjectBaseDir", "sonarExclusions", "sonarSources", "sonarJavaBinaries")

[updateJsonForDeployment.groovy](https://usapbitbucket01.cotiviti.com/projects/PCAIP/repos/devops-cicd-library/browse/vars/updateJsonForDeployment.groovy)
This library is used for feature branch builds where CI-CD takes place. This particular library will update the Json files where each war file and it's maven GAV (groupId, ArtifactID and Version) are maintained. Based on these details deployment will be done to Jboss application server.
**Usage**

 - updateJsonForDeployment("workspace dir", 'artifactName.packagingType', 'targetEnvironment', 'artifactVersion')

>  Example:



    `updateJsonForDeployment("${env.WORKSPACE}/CD_Repo", 'builder-app.ear', 'CICD_ENV', VERSION)`

## Jenkins pipeline in PCAIPP project which uses some of these libraries
[https://usapbitbucket01.cotiviti.com/projects/PCAIPP/repos/clientprofile/browse/feature-pipeline.groovy](https://usapbitbucket01.cotiviti.com/projects/PCAIPP/repos/clientprofile/browse/feature-pipeline.groovy)



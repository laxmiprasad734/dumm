//class variables {
	final String sonarHostUrl="https://bamboo.ihtech.com/sonarqube"
//}
	

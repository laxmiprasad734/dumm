import com.cotiviti.*

def call(String sonarProjectKey, String sonarProjectName, String sonarProjectVersion, String sonarProjectBaseDir, String sonarExclusions, String sonarSources, String sonarJavaBinaries) {
	def scannerHome = tool name: 'SonarQube Scanner', type: 'hudson.plugins.sonar.SonarRunnerInstallation'            
	withSonarQubeEnv(credentialsId: 'SONAR-QUBE-TOKEN', installationName: 'IPDE-SONAR') {
	  sh "${scannerHome}/bin/sonar-scanner " +
	  		"-Dsonar.host.url="+Constants.SONAR_HOST_URL+" "+
	  		"-Dsonar.projectKey=${sonarProjectKey} "+ 
	  		"-Dsonar.projectName=\"${sonarProjectName}\" "+
	  		"-Dsonar.projectVersion=${sonarProjectVersion} "+
	  		"-Dsonar.sourceEncoding=\"UTF-8\" "+
	  		"-Dsonar.projectBaseDir=${sonarProjectBaseDir} "+ 
	  		"-Dsonar.exclusions=${sonarExclusions} "+
	  		"-Dsonar.scm.provider=\"git\" "+
	  		"-Dsonar.sources=${sonarSources} "+
	  		"-Dsonar.java.binaries=${sonarJavaBinaries}"           
	}

}
import com.cotiviti.*
def call (DOCKER_REPO, MAVEN_REPO)
{  
    node('docker')
    {
        def veracodeUrl
        def groupID
        def Projectname = pwd().tokenize('/')[-3].replace("_","").toLowerCase()
        //Need to work on pwd
        def GitScm = "https://bitbucket.cotiviti.com/scm/awtraining/devops-dockerfile.git"
        def artifactory_Release = "https://artifactory.cotiviti.com/artifactory/${MAVEN_REPO}"
        def Docker_Registry = "artifactory.cotiviti.com"
        def Docker_Image = Docker_Registry + "/${DOCKER_REPO}/" + "${APP}:${VERSION}"
        def imgUrl = "https://${Docker_Registry}/ui/native/ppm-ecl-docker/${APP}/${VERSION}"
        def build_res,build_duration,epoch_time
        try {
            stage('Checkout Source'){
                    cleanWs()
                    sh 'git config --global http.sslVerify false'
                    checkout([$class: 'GitSCM', branches: [[name: "master"]],doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'LocalBranch', localBranch: "**"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId:'svcpbbejenkins_enterprise' , url: "${GitScm}"]]])
            }
            stage('Get jar file'){
                groupID = "com/cotiviti"
                //artifactID = pom.artifactId
                if (env.VERSION.contains('-SNAPSHOT')){
                    sh '''
                        echo groupID is.................::: '''+groupID+'''
                        curl -sSf --output latest.txt "https://artifactory.cotiviti.com/artifactory/api/search/latestVersion?g='''+groupID+'''&a='''+APP+'''&v='''+VERSION+'''&repos=ppm-ecl-maven-snapshots"
                      '''
                    def ver = readFile "${env.WORKSPACE}/latest.txt"
                    echo "Latest version from JFrog Artifactory is::::${ver}"
                    url="https://artifactory.cotiviti.com/artifactory/ppm-ecl-maven-snapshots/"+groupID+"/"+APP+"/"+VERSION+"/"+APP+"-"+ver+".jar"
                    sh "curl -sSf ${url} --output ${APP}-${VERSION}.jar"
                } else {
                     sh ''' 
                      curl -LO -sSf '''+artifactory_Release+'''/'''+groupID+'''/${APP}/${VERSION}/${APP}-${VERSION}.jar 
                      '''
                }
            }
            stage('Update Variables'){
                sh "sed -i -e 's/version/${VERSION}/g' ./Dockerfile"
                sh "sed -i -e 's/serviceName/${APP}/g' ./Dockerfile"
            }
            stage('Build the image'){
                withCredentials([usernamePassword(credentialsId: 'JFrog-Artifactory-svc2', passwordVariable:'JFROG_PASSWORD',usernameVariable: 'JFROG_USERNAME')]){
                 sh '''
                        docker build --no-cache -t '''+Docker_Image+'''  . 
                  '''
                }
            }
            stage('Push the Image'){
                withCredentials([usernamePassword(credentialsId: 'JFrog-Artifactory-svc2', passwordVariable:'JFROG_PASSWORD',usernameVariable: 'JFROG_USERNAME')]){
                    sh '''
                            docker login -u $JFROG_USERNAME -p $JFROG_PASSWORD '''+ Docker_Registry+''' && docker push '''+Docker_Image+''' 
                        '''
                }
            }
            /*if (!env.VERSION.contains('-SNAPSHOT')){
                stage('Veracode scan'){
                    /*sh ''' 
                        srcclr scan --image  '''+Docker_Image+''' >> ${WORKSPACE}/detailedreport.txt 
                    '''
                    echo "Skipping veracode scan"
                }
                stage('Get Report'){
                sh ''' 
                        apk update && apk add libreoffice
                        libreoffice --convert-to "pdf" ${WORKSPACE}/detailedreport.txt
                   '''
                }
                stage("Get the report url "){
                   veracodeUrl= sh(script:"grep -w 'Full Report Details' ${WORKSPACE}/detailedreport.txt | awk '{print \$4}'",returnStdout: true)
                   println "${veracodeUrl}"
                }
            }*/
            stage('Delete Local Image '){
                sh '''
                        docker rmi '''+Docker_Image+''' 
                '''
            }
        }
        catch(Exception e) {
            currentBuild.result="FAILURE"
        }
        finally {
            /*stage('Push to InfluxDB'){
                build_res=currentBuild.currentResult
                build_duration=currentBuild.duration/1000
                epoch_time = sh returnStdout: true, script: 'date +%s%N'
                sh "curl -XPOST '${Constants.INFLUX_DB_URL}/write?db=ipde_jenkins_build_data'  --data-binary 'Image_Build_data,Projectname=$Projectname,app_name=$APP,build_result=$build_res,BuildThru=$BuildThru Docker_Image=\"$Docker_Image\",build_number=$env.BUILD_NUMBER,build_url=\"$env.BUILD_URL\",build_agent_name=\"$env.NODE_NAME\",build_exec_time=$build_duration $epoch_time'"
            }*/
            stage('Send Email Notification'){
                if (!env.VERSION.contains('-SNAPSHOT')){
                  //emailNotification.sendEmailBuildImage("$EmailRecipients","$APP:${VERSION}","${imgUrl}","$veracodeUrl")
                }else{
                   //sendDockerEmailNotification("$EmailRecipients","$APP","${VERSION}") 
                }
            }
        }
    }
}

def call (String sProjectname)
{  
    node('docker')
    {
        def veracodeUrl
        def groupID
        def Projectname = sProjectname
        //Need to work on pwd
        def GitScm = Constants.BITBUCKET_BASE_URL+"${Projectname}/${APP}.git"
        def artifactory_Release = "https://artifactory.cotiviti.com/artifactory/ppm-ecl-maven/"
        def Docker_Registry = "artifactory.cotiviti.com"
        def Docker_Image = Docker_Registry + "/ppm-ecl-docker/" + "${APP}:${VERSION}"
        def imgUrl = "https://${Docker_Registry}/ui/native/ppm-ecl-docker/${APP}/${VERSION}"
        def build_res,build_duration,epoch_time
        try {
            stage('Checkout Source'){
                    cleanWs()
                    sh 'git config --global http.sslVerify false'
                    checkout([$class: 'GitSCM', branches: [[name: "master"]],doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'LocalBranch', localBranch: "**"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId:'svcpbbejenkins_enterprise' , url: "${GitScm}"]]])
            }
            stage('Get jar file'){
                pom = readMavenPom file: "pom.xml"
                groupID = pom.groupId
                if (groupID == null){
                    groupID = pom.parent.groupId
                }
                groupID = groupID.replace('.','/')
                //artifactID = pom.artifactId
                if (env.VERSION.contains('-SNAPSHOT')){
                    sh '''
                        echo groupID is.................::: '''+groupID+'''
                        curl -sSf --output latest.txt "https://artifactory.cotiviti.com/artifactory/api/search/latestVersion?g='''+groupID+'''&a='''+APP+'''&v='''+VERSION+'''&repos=ppm-ecl-maven-snapshots"
                      '''
                    def ver = readFile "${env.WORKSPACE}/latest.txt"
                    echo "Latest version from JFrog Artifactory is::::${ver}"
                    url="https://artifactory.cotiviti.com/artifactory/ppm-ecl-maven-snapshots/"+groupID+"/"+APP+"/"+VERSION+"/"+APP+"-"+ver+".jar"
                    sh "curl -sSf ${url} --output ${APP}-${VERSION}.jar"
                } else {
                     sh ''' 
                      curl -LO -sSf '''+artifactory_Release+'''/'''+groupID+'''/${APP}/${VERSION}/${APP}-${VERSION}.jar 
                      '''
                }
            }
            stage('Update Variables'){
                sh "sed -i -e 's/version/${VERSION}/g' ./Dockerfile"
            }
            stage('Build the image'){
                withCredentials([usernamePassword(credentialsId: 'JFrog-Artifactory-svc2', passwordVariable:'JFROG_PASSWORD',usernameVariable: 'JFROG_USERNAME')]){
                 sh '''
                        docker build -t '''+Docker_Image+'''  . 
                  '''
                }
            }
            stage('Push the Image'){
                withCredentials([usernamePassword(credentialsId: 'JFrog-Artifactory-svc2', passwordVariable:'JFROG_PASSWORD',usernameVariable: 'JFROG_USERNAME')]){
                    sh '''
                            docker login -u $JFROG_USERNAME -p $JFROG_PASSWORD '''+ Docker_Registry+''' && docker push '''+Docker_Image+''' 
                        '''
                }
            }
            if (!env.VERSION.contains('-SNAPSHOT')){
                stage('Veracode scan'){
                    sh ''' 
                        srcclr scan --image  '''+Docker_Image+''' >> ${WORKSPACE}/detailedreport.txt 
                    '''
                }
                stage('Get Report'){
                sh ''' 
                        apk update && apk add libreoffice
                        libreoffice --convert-to "pdf" ${WORKSPACE}/detailedreport.txt
                   '''
                }
                stage("Get the report url "){
                   veracodeUrl= sh(script:"grep -w 'Full Report Details' ${WORKSPACE}/detailedreport.txt | awk '{print \$4}'",returnStdout: true)
                   println "${veracodeUrl}"
                }
            }
            stage('Delete Local Image '){
                sh '''
                        docker rmi '''+Docker_Image+''' 
                '''
            }
        }
        catch(Exception e) {
            currentBuild.result="FAILURE"
        }
        finally {
            /*stage('Push to InfluxDB'){
                build_res=currentBuild.currentResult
                build_duration=currentBuild.duration/1000
                epoch_time = sh returnStdout: true, script: 'date +%s%N'
                //sh "curl -XPOST '${Constants.INFLUX_DB_URL}/write?db=ipde_jenkins_build_data'  --data-binary 'Image_Build_data,Projectname=$Projectname,app_name=$APP,build_result=$build_res,BuildThru=$BuildThru Docker_Image=\"$Docker_Image\",build_number=$env.BUILD_NUMBER,build_url=\"$env.BUILD_URL\",build_agent_name=\"$env.NODE_NAME\",build_exec_time=$build_duration $epoch_time'"
            }*/
            stage('Send Email Notification'){
                if (!env.VERSION.contains('-SNAPSHOT')){
                  //emailNotification.sendEmailBuildImage("$EmailRecipients","$APP:${VERSION}","${imgUrl}","$veracodeUrl")
                }else{
                   //sendDockerEmailNotification("$EmailRecipients","$APP","${VERSION}") 
                }
            }
        }
    }
}

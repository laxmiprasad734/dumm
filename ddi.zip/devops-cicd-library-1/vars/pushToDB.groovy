import com.cotiviti.*

def call(String responseCode, String bugsCount, String codeSmellsCount, String duplicatedCode, String vulnerabilitiesCount){
	def pushToDatabase = new PushToDatabase()
	pushToDatabase.push(responseCode, bugsCount, codeSmellsCount, duplicatedCode, vulnerabilitiesCount)
}
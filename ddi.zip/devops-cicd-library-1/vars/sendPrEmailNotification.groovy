import com.cotiviti.*
def call(String EmailRecipients, String sonarProjectKey, String sonarProjectName){
  def codeSmellsCount, bugsCount, duplicatedCode, vulnerabilitiesCount, qualityGateStatus
  def getQualityMetrics = new GetQualityMetrics()
  (codeSmellsCount, bugsCount, duplicatedCode, vulnerabilitiesCount, qualityGateStatus) = getQualityMetrics.get(sonarProjectKey)
   if(qualityGateStatus == 'OK'){
      StatusString="<p><font color=\"green\">Passed</font></p>"
      currentBuild.result="SUCCESS"
  } else {
      StatusString="<p><font color=\"red\">Failed</font></p>"
      currentBuild.result="SUCCESS"
  }

  emailext attachmentsPattern: '*.LOG', mimeType: 'text/html', body: """<!DOCTYPE html>
                  <html>
                     <head>
                        <style>
                           table.blueTable {
                           table-layout: auto;
                           border: 1px solid #1C6EA4;
                           text-align: left;
                           border-collapse: collapse;
                           }
                           table.blueTable td {
                           font-size: 18px;
                           white-space:nowrap;
                           padding:10px;
                           border: 1px solid #AAAAAA;
                           }
                           table.blueTable tr:nth-child(even) {
                           /*background: #D0E4F5; */
                           }
                           table.blueTable thead tr {
                           background-color: #5bda65;
                           text-align: center;
                           }
                           table.blueTable tbody tr td:last-child{
                           background-color:#f3f2f2;
                           }
                        </style>
                     </head>
                     <body>
                        <table class="blueTable">
                           <thead>
                              <tr>
                                 <td colspan='2'><b>BUILD REPORT</b></td>
                              </tr>
                           </thead>
                           <tbody>
                              <tr>
                                 <td><strong>Build No</strong></td>
                                 <td>${env.BUILD_NUMBER}</td>
                              </tr>
                              <tr>
                                 <td><strong>BRANCH NAME</strong></td>
                                 <td>${env.BRANCH_NAME}</td>
                              </tr>
                              <tr>
                                 <td><strong>Build URL</strong></td>
                                 <td>${env.BUILD_URL}</td>
                              </tr>
                              <tr>
                                  <td><b>Sonar URL</b></td>
                                  <td>$sonarURL</td>
                              </tr>
                              <tr>
                                  <td><b>Reliability</b></td>
                                  <td>Bugs: $bugsCount</td>
                              </tr>
                              <tr>
                                  <td><b>Security</b></td>
                                  <td>Vulnerabilities: $vulnerabilitiesCount</td>
                              </tr>
                              <tr>
                                  <td><b>Maintainability</b></td>
                                  <td>Code Smells: $codeSmellsCount</td>
                              </tr>
                              <tr>
                                  <td><b>Duplications</b></td>
                                  <td>Duplicated Code: $duplicatedCode%</td>
                              </tr>                                        
                              <tr>
                                  <td><b>Quality Gate Status</b></td>
                                  <td>$StatusString</td>
                              </tr>                        
                           </tbody>
                        </table>
                     </body>
                  </html>
                  """, subject: "${sonarProjectName} build status on ${env.BRANCH_NAME} branch is ${currentBuild.result}", to: "PCA-MCurieTeam@cotiviti.com,$EmailRecipients"

}
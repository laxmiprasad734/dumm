import com.cotiviti.*

def call(String workspace, String warName, String targetBranch, String version){
	dir(workspace){
		warName=warName.trim()
		version=version.trim()
		sh 'chmod +x updateversion.py'
		sh "python updateversion.py $warName $version"			
		withCredentials([usernamePassword(credentialsId: Constants.BITBUCKET_CREDENTIALS_ID, passwordVariable: 'GIT_PASSWORD', usernameVariable: 'GIT_USERNAME')]) {
		  sh "git config --global user.name \"jenkinsuser\""
		  sh "git config --global user.email Jenkins_Devops@cotiviti.com"
		  sh "git commit -am \"update version of $warName with ${version}\""
		  try{
		    sh """
		    set +x
		    chmod +x Expect
		    ./Expect "git push https://$GIT_USERNAME@usapbitbucket01.cotiviti.com/scm/pcaip/qa-jboss7-ipde-jbpm.git HEAD:$targetBranch" "$GIT_PASSWORD"
		    """
		  }
		  catch(Exception e){
		    sh """
		    ./Expect "git fetch https://$GIT_USERNAME@usapbitbucket01.cotiviti.com/scm/pcaip/qa-jboss7-ipde-jbpm.git HEAD:$targetBranch" "$GIT_PASSWORD"
		    ./Expect "git push https://$GIT_USERNAME@usapbitbucket01.cotiviti.com/scm/pcaip/qa-jboss7-ipde-jbpm.git HEAD:$targetBranch" "$GIT_PASSWORD"
		    """
		  }                
		}
	}
}

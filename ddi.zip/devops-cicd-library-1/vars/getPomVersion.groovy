def call(String workspace){
	dir(workspace){
		if(env.BRANCH_NAME =~ /^feature\//){
			SHORTREV=sh label: '', returnStdout: true, script: 'git rev-parse --short HEAD'
			SHORTREV = SHORTREV.trim()
			BUILD_TIME="${DATE_NOW}"
			pom = readMavenPom file: 'pom.xml'    //you need to install pipeline utility steps plugin in jenkins for this to work
			VERSION = pom.version.replaceAll('SNAPSHOT', BUILD_TIME + "." + SHORTREV)
			VERSION = VERSION + "-" + "SNAPSHOT"
			VERSION=VERSION.trim()
			return VERSION
        }else{
			pom=readMavenPom file: 'pom.xml'
			VERSION=pom.version.tokenize(".")
			VERSION[-1]="$env.BUILD_NUMBER"
			VERSION=VERSION.join(".")
			return VERSION
		}
	}
}

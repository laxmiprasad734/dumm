import com.cotiviti.*
def call(String sonarProjectKey){
	def codeSmellsCount, bugsCount, duplicatedCode, vulnerabilitiesCount, qualityGateStatus
	def sonarProjectCheck=Constants.SONAR_HOST_URL+"/api/components/show?key=$sonarProjectKey"
	def responseCode=sh returnStdout: true, script: "curl --silent  $sonarProjectCheck"
	def getQualityMetrics = new GetQualityMetrics()
	(codeSmellsCount, bugsCount, duplicatedCode, vulnerabilitiesCount, qualityGateStatus) = getQualityMetrics.get(sonarProjectKey)
	def dbPush = new PushToDatabase()
	dbPush.push(responseCode, bugsCount, codeSmellsCount, duplicatedCode, vulnerabilitiesCount, qualityGateStatus)	

}
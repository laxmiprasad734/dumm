import com.cotiviti.*
def call(String mvnGoals, String mvnParameters){
	if (env.BUILD_URL =~ /pcarcp/ && mvnGoals =~ /release/){
		pom=readMavenPom file: 'pom.xml'
		VERSION=pom.version.tokenize(".")
		VERSION[-1]="$env.BUILD_NUMBER"
		VERSION=VERSION.join(".")
		println VERSION
		sh """
			git config --global user.name \"jenkinsuser\"
			git config --global user.email Jenkins_Devops@cotiviti.com
			mvn -Dtycho.mode=maven org.eclipse.tycho:tycho-versions-plugin:set-version -DnewVersion="""+VERSION+"""
			mvn deploy -U -Dmaven.test.skip=false -Dmaven.test.failure.ignore=true
		"""
	} else {
		sh """
			git config --global user.name \"jenkinsuser\"
			git config --global user.email Jenkins_Devops@cotiviti.com
			mvn $mvnGoals $mvnParameters
		"""
	}
}
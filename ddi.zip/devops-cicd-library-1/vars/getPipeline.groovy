def call(){

    def BranchName=branchName()

    if (isFeature(BranchName) || isDev(BranchName)){
        return 'feature-pipeline.groovy'
        //evaluate readTrusted('feature-pipeline.groovy')
    }
    else if (isPR()){
        return 'pr-pipeline.groovy'
        //evaluate readTrusted('pr-pipeline.groovy')
    }
    else if (isRelease(BranchName) || isMaster(BranchName)){
        return 'release-pipeline.groovy'
        //evaluate readTrusted('release-pipeline.groovy')
    }
    else {
        println "Please check the branch naming convention.. It should be either feature/develop/dev/release/master/hotfix"
    }

}

def branchName(){
    return env.BRANCH_NAME
}

def isPR(){
    if (env.BRANCH_NAME ==~ /PR-\d+/){ return true }
}

def isRelease(String BranchName){
    if (BranchName.toLowerCase() =~ /^release\//){ return true }
}

def isDev(String BranchName){
    if (BranchName.toLowerCase() ==~ /^develop$/ || BranchName.toLowerCase() ==~ /^dev$/){ return true }
}

def isFeature(String BranchName){
    if (BranchName.toLowerCase() =~ /^feature\//){ return true }
}
def isMaster(String BranchName){
    if (BranchName ==~ /^master$/ || BranchName.toLowerCase() =~ /^hotfix\//){ return true }
}


def notifyBitbucketServer(String status)
{
    println "### Started running the notifyBitbucketServer() method from utils.groovy library ###"
    if('SUCCESS' == status || 'FAILED' == status) 
    {
        // Set result of currentBuild !Important!
        currentBuild.result = status
    }
    try
    {
        def commitId = getCommitId()
        notifyBitbucket(
            commitSha1: commitId, 
            considerUnstableAsSuccess: true, 
            disableInprogressNotification: false, 
            ignoreUnverifiedSSLPeer: true, 
            includeBuildNumberInKey: false, 
            prependParentProjectKey: false, 
            projectKey: ''
        )
    }
    catch(Exception e)
    {
        println("### ERROR in notifyBitbucketServer() method of utils.groovy library file.....: "+e.getMessage())
    }
    println "### Completed running the notifyBitbucketServer() method from utils.groovy library ###"
}

def getCommitId()
{
  	println "### Started running the getCommitId() method from utils.groovy library ###"
    commitId = sh (script: "git rev-parse HEAD", returnStdout: true)
    commitId = commitId.readLines().remove(0)
    println "### commitId is..........: ${commitId} ###"
  	println "### Completed running the getCommitId() method from utils.groovy library ###"
}

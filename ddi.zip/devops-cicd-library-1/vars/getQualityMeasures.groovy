import com.cotiviti.*

def call(String sonarApiMeasures){
    def SonarMeasuresJson=sh returnStdout: true, script: "curl -s --request GET $sonarApiMeasures"
    def ParsedJson = parseJsonResponse(SonarMeasuresJson)
    println ParsedJson
    def array = ParsedJson.component.measures
    for(def member : array) {
        if(member.metric == 'code_smells'){
            codeSmellsCount = member.value            
        }
        if(member.metric == 'bugs'){
            bugsCount = member.value            
        }
        // if(member.metric == 'coverage'){
        //     coverage_percentage = member.value            
        // }
        if(member.metric == 'duplicated_lines_density'){
            duplicatedCode = member.value            
        }
        if(member.metric == 'vulnerabilities'){
            vulnerabilitiesCount = member.value            
        }
        if(member.metric == 'alert_status'){
            qualityGateStatus = member.value            
        }
    }
    return [codeSmellsCount, bugsCount, duplicatedCode, vulnerabilitiesCount, qualityGateStatus]   
}
import com.cotiviti.*

def call(String response){
	def jsonParser = new JsonParser()
	return jsonParser.parseJson(response)
}